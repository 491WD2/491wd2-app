# Mop floor

Type: Chores
Status: Not started
Room: 🚽 Half Bath (https://www.notion.so/Half-Bath-2ef97e9c2a3181d881c4f8476b0304b8?pvs=21)
Completion %: 0%
Frequency: Weekly

### ✏️ Cleaning Description

---

Mop half bath floor weekly to maintain cleanliness and hygiene.

---

### ✅ What I have to-do

---

- [ ]  Sweep floor first
- [ ]  Mop with cleaner
- [ ]  Clean around toilet base
- [ ]  Let dry completely

### ❌ What I need to avoid

---

- Mopping without sweeping
- Missing corners
- Using dirty mop water

---