# Disinfect all surfaces

Type: Chores
Status: Not started
Completion %: 0%
Frequency: Weekly

### ✏️ Cleaning Description

---

Clean shower doors and walls weekly to remove soap scum and water spots.

---

### ✅ What I have to-do

---

- [ ]  Spray with bathroom cleaner
- [ ]  Scrub glass doors and tiles
- [ ]  Rinse thoroughly
- [ ]  Squeegee or dry

### ❌ What I need to avoid

---

- Using abrasive scrubbers on glass
- Leaving soap residue
- Missing door tracks

---