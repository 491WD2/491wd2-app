# Wipe down baseboards

Type: Chores
Status: Not started
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Wipe down kitchen baseboards monthly to remove grease, dust, and food splatters.

---

### ✅ What I have to-do

---

- [ ]  Vacuum or dust first
- [ ]  Wipe with degreaser
- [ ]  Scrub stubborn spots
- [ ]  Dry completely

### ❌ What I need to avoid

---

- Using too much water
- Leaving grease buildup
- Damaging paint finish

---