# Dust ceiling corners for cobwebs

Type: Chores
Status: Not started
Room: 🚶 Halls (https://www.notion.so/Halls-2ef97e9c2a31812b92fed8399ea05356?pvs=21)
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Dust ceiling corners monthly to remove cobwebs and spider webs.

---

### ✅ What I have to-do

---

- [ ]  Use extension duster
- [ ]  Check all corners and edges
- [ ]  Remove webs completely
- [ ]  Dust light fixtures too

### ❌ What I need to avoid

---

- Leaving partial webs
- Missing behind curtains
- Smearing webs on walls

---