# Wipe down countertops

Type: Chores
Status: Not started
Completion %: 0%
Frequency: Daily

### ✏️ Cleaning Description

---

Wipe down all kitchen countertops, removing crumbs, spills, and debris. Use appropriate cleaner for your countertop material.

---

### ✅ What I have to-do

---

- [ ]  Clear counters of items
- [ ]  Wipe down all surfaces
- [ ]  Clean around appliances
- [ ]  Dry with clean cloth

### ❌ What I need to avoid

---

- Using harsh chemicals on delicate surfaces
- Leaving surfaces wet
- Forgetting corners and edges

---