# Clean windows

Type: Chores
Status: Not started
Room: 🛏️ Bedroom (https://www.notion.so/Bedroom-2ef97e9c2a318104bfe5c06efed42020?pvs=21)
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Clean bedroom windows monthly to remove dust, smudges, and improve natural light.

---

### ✅ What I have to-do

---

- [ ]  Dust window frames and sills
- [ ]  Spray glass with cleaner
- [ ]  Wipe with microfiber cloth
- [ ]  Buff to streak-free shine

### ❌ What I need to avoid

---

- Cleaning in direct sunlight
- Using paper towels that streak
- Missing window tracks

---