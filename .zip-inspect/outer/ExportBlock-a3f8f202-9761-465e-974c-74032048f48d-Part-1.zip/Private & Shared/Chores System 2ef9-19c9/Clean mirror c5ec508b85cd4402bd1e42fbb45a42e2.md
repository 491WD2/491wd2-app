# Clean mirror

Type: Chores
Status: Not started
Room: 🚽 Half Bath (https://www.notion.so/Half-Bath-2ef97e9c2a3181d881c4f8476b0304b8?pvs=21)
Completion %: 0%
Frequency: Weekly

### ✏️ Cleaning Description

---

Clean bathroom mirror weekly to remove toothpaste splatter, water spots, and smudges.

---

### ✅ What I have to-do

---

- [ ]  Spray mirror with glass cleaner
- [ ]  Wipe with microfiber cloth
- [ ]  Buff to shine
- [ ]  Clean mirror edges

### ❌ What I need to avoid

---

- Using paper towels
- Leaving streaks
- Missing toothpaste spots

---