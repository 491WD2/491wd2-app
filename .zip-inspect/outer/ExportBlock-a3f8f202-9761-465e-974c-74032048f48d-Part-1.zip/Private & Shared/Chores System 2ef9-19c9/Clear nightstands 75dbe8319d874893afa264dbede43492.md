# Clear nightstands

Type: Chores
Status: Not started
Room: 🛏️ Bedroom (https://www.notion.so/Bedroom-2ef97e9c2a318104bfe5c06efed42020?pvs=21)
Completion %: 0%
Frequency: Daily

### ✏️ Cleaning Description

Remove items from nightstands and organize properly, creating a clean, clutter-free, and peaceful bedroom environment.

---

### 📋 Step-by-Step Instructions

- [ ]  Remove all items from nightstand surfaces
- [ ]  Sort items into keep, relocate, or discard piles
- [ ]  Dust the nightstand surface thoroughly
- [ ]  Wipe down with appropriate cleaner
- [ ]  Dry surface completely
- [ ]  Return only essential nighttime items
- [ ]  Arrange items neatly and accessibly
- [ ]  Put away items that belong elsewhere

### ⚠️ Important Safety & Mistakes to Avoid

- Don't let clutter accumulate over multiple days
- Avoid placing items that don't belong in bedroom
- Never overload the nightstand surface
- Don't forget to relocate items to their proper homes
- Avoid keeping expired medications or old receipts

---