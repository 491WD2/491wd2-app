# Clean light fixture

Type: Chores
Status: Not started
Room: 🍽️ Dining Room (https://www.notion.so/Dining-Room-2ef97e9c2a318192bdd0f0418b269200?pvs=21)
Completion %: 0%
Frequency: Weekly

### ✏️ Cleaning Description

---

Clean dining room light fixture weekly to remove dust and maintain brightness.

---

### ✅ What I have to-do

---

- [ ]  Turn off and let cool
- [ ]  Dust fixture thoroughly
- [ ]  Wipe with damp cloth
- [ ]  Dry completely

### ❌ What I need to avoid

---

- Cleaning while hot
- Using excess water
- Leaving streaks

---