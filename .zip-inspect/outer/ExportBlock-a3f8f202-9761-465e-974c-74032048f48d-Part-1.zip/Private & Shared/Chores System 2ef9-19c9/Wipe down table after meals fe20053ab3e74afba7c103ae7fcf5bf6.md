# Wipe down table after meals

Type: Chores
Status: Not started
Room: 🍽️ Dining Room (https://www.notion.so/Dining-Room-2ef97e9c2a318192bdd0f0418b269200?pvs=21)
Completion %: 0%
Frequency: Daily

### ✏️ Cleaning Description

---

Wipe down the dining table after each meal to remove crumbs, spills, and stains.

---

### ✅ What I have to-do

---

- [ ]  Remove items from table
- [ ]  Brush crumbs into hand
- [ ]  Wipe with damp cloth
- [ ]  Dry thoroughly

### ❌ What I need to avoid

---

- Using too much water on wood
- Leaving sticky residue
- Sweeping crumbs onto floor

---