import React from 'react';
import { TrendingUp, DollarSign, Users, Calendar } from 'lucide-react';

export function ReportsView() {
  const stats = [
    {
      id: 1,
      label: 'Today\'s Revenue',
      value: '$1,850',
      change: '+12%',
      icon: DollarSign,
      color: 'from-[#E8D5E8] to-[#D4C5E8]',
      textColor: 'text-[#8B5A7C]',
    },
    {
      id: 2,
      label: 'Total Clients',
      value: '248',
      change: '+8%',
      icon: Users,
      color: 'from-[#E8F4F8] to-[#D4E5F8]',
      textColor: 'text-[#5A8B9E]',
    },
    {
      id: 3,
      label: 'Appointments Today',
      value: '12',
      change: '+5%',
      icon: Calendar,
      color: 'from-[#F0F4E8] to-[#E5F0D4]',
      textColor: 'text-[#6B8B5A]',
    },
    {
      id: 4,
      label: 'Growth Rate',
      value: '15%',
      change: '+3%',
      icon: TrendingUp,
      color: 'from-[#FFF4E8] to-[#FFE8D4]',
      textColor: 'text-[#8B7A5A]',
    },
  ];

  const recentTransactions = [
    {
      id: 1,
      client: 'Sarah Kim',
      service: 'Hair Cut & Style',
      amount: 125.0,
      time: '09:30 AM',
    },
    {
      id: 2,
      client: 'Emma Lee',
      service: 'Color Treatment',
      amount: 280.0,
      time: '11:15 AM',
    },
    {
      id: 3,
      client: 'Jessica Park',
      service: 'Hair Perm',
      amount: 195.0,
      time: '01:45 PM',
    },
    {
      id: 4,
      client: 'Michelle Choi',
      service: 'Treatment & Styling',
      amount: 165.0,
      time: '03:20 PM',
    },
  ];

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <div className="mb-8">
        <h2 className="text-3xl text-gray-900 mb-2">Reports</h2>
        <p className="text-gray-400">Business insights and analytics</p>
      </div>

      <div className="grid grid-cols-4 gap-6 mb-8">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div
              key={stat.id}
              className="bg-white rounded-3xl p-6 border border-gray-100"
            >
              <div
                className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${stat.color} flex items-center justify-center mb-4`}
              >
                <Icon className={`w-6 h-6 ${stat.textColor}`} />
              </div>
              <p className="text-sm text-gray-500 mb-1">{stat.label}</p>
              <p className="text-2xl text-gray-900 mb-2">{stat.value}</p>
              <p className="text-sm text-[#6B8B5A]">{stat.change} from last week</p>
            </div>
          );
        })}
      </div>

      <div className="bg-white rounded-3xl p-6 border border-gray-100">
        <h3 className="text-xl text-gray-900 mb-6">Recent Transactions</h3>
        <div className="space-y-4">
          {recentTransactions.map((transaction) => (
            <div
              key={transaction.id}
              className="flex items-center justify-between py-4 border-b border-gray-100 last:border-0"
            >
              <div>
                <p className="text-gray-900 mb-1">{transaction.client}</p>
                <p className="text-sm text-gray-500">{transaction.service}</p>
              </div>
              <div className="text-right">
                <p className="text-lg text-gray-900 mb-1">
                  ${transaction.amount.toFixed(2)}
                </p>
                <p className="text-sm text-gray-400">{transaction.time}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
