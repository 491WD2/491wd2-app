# Dust all surfaces

Type: Chores
Status: Not started
Room: 🛏️ Bedroom (https://www.notion.so/Bedroom-2ef97e9c2a318104bfe5c06efed42020?pvs=21)
Completion %: 0%
Frequency: Weekly

### ✏️ Cleaning Description

---

Clean tub and shower weekly to remove soap scum, mildew, and hard water buildup.

---

### ✅ What I have to-do

---

- [ ]  Spray with bathroom cleaner
- [ ]  Let sit 5-10 minutes
- [ ]  Scrub all surfaces
- [ ]  Rinse thoroughly

### ❌ What I need to avoid

---

- Using abrasives on acrylic
- Missing faucet and fixtures
- Not rinsing completely

---