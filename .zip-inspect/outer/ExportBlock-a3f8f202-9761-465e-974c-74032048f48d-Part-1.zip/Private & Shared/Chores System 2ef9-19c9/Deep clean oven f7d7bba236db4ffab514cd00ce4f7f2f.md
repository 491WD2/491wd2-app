# Deep clean oven

Type: Chores
Status: Not started
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Deep clean the oven monthly to remove baked-on grease and food residue.

---

### ✅ What I have to-do

---

- [ ]  Remove racks and soak
- [ ]  Apply oven cleaner inside
- [ ]  Let sit per instructions
- [ ]  Scrub and wipe clean

### ❌ What I need to avoid

---

- Cleaning heating elements
- Using oven while wet
- Mixing cleaning chemicals

---