# Wipe down walls and doors

Type: Chores
Status: Not started
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Wipe down walls and doors monthly to remove fingerprints, dust, and marks.

---

### ✅ What I have to-do

---

- [ ]  Dust walls top to bottom
- [ ]  Wipe with mild cleaner
- [ ]  Clean all door surfaces
- [ ]  Spot clean marks

### ❌ What I need to avoid

---

- Saturating painted surfaces
- Using abrasive cleaners
- Missing door handles

---