# Pick up clutter and put items away

Type: Chores
Status: Not started
Completion %: 0%
Frequency: Daily

### ✏️ Cleaning Description

---

Remove clutter and return items to their proper places throughout the room.

---

### ✅ What I have to-do

---

- [ ]  Walk through and gather items
- [ ]  Sort items by destination
- [ ]  Return each item to proper place
- [ ]  Clear all surfaces

### ❌ What I need to avoid

---

- Moving clutter from one spot to another
- Leaving items in wrong rooms
- Creating piles to deal with later

---