# Wipe down sink and counter

Type: Chores
Status: Not started
Completion %: 0%
Frequency: Daily

### ✏️ Cleaning Description

---

Wipe down bathroom sink and counter daily to remove toothpaste, soap scum, and water spots.

---

### ✅ What I have to-do

---

- [ ]  Clear counter of items
- [ ]  Spray and wipe sink
- [ ]  Clean faucet and handles
- [ ]  Wipe entire counter

### ❌ What I need to avoid

---

- Leaving toothpaste buildup
- Missing behind faucet
- Using abrasive cleaners

---