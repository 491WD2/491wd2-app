import React, { useState } from 'react';
import { X, Phone, Mail, Calendar, DollarSign, RefreshCcw } from 'lucide-react';

interface ClientDetailModalProps {
  client: any;
  onClose: () => void;
}

export function ClientDetailModal({ client, onClose }: ClientDetailModalProps) {
  const [showRefundModal, setShowRefundModal] = useState(false);
  const [refundAmount, setRefundAmount] = useState('');
  const [refundReason, setRefundReason] = useState('');

  const mockTransactions = [
    {
      id: 1,
      date: '2026-02-05',
      service: 'Hair Cut & Style',
      amount: 125.0,
      status: 'completed',
      stylist: 'Jenny',
    },
    {
      id: 2,
      date: '2026-01-22',
      service: 'Color Treatment',
      amount: 280.0,
      status: 'completed',
      stylist: 'Min',
    },
    {
      id: 3,
      date: '2026-01-10',
      service: 'Hair Perm',
      amount: 195.0,
      status: 'completed',
      stylist: 'Jenny',
    },
  ];

  const handleRefund = (transaction: any) => {
    setShowRefundModal(true);
  };

  const processRefund = (type: 'full' | 'partial') => {
    if (type === 'full') {
      alert('Full refund processed');
    } else if (refundAmount && refundReason) {
      alert(`Partial refund of $${refundAmount} processed`);
    }
    setShowRefundModal(false);
    setRefundAmount('');
    setRefundReason('');
  };

  return (
    <div className="fixed inset-0 bg-black/20 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-8 border-b border-gray-100">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#E8D5E8] to-[#D4C5E8] flex items-center justify-center">
              <span className="text-xl text-[#8B5A7C]">
                {client.name
                  .split(' ')
                  .map((n: string) => n[0])
                  .join('')}
              </span>
            </div>
            <div>
              <h2 className="text-2xl text-gray-900">{client.name}</h2>
              <p className="text-gray-400 mt-1">Client Details</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-50 rounded-xl transition-colors"
          >
            <X className="w-6 h-6 text-gray-400" />
          </button>
        </div>

        <div className="p-8 space-y-6">
          {/* Contact Information */}
          <div className="bg-gray-50 rounded-2xl p-6">
            <h3 className="text-lg text-gray-900 mb-4">Contact Information</h3>
            <div className="space-y-3">
              <div className="flex items-center gap-3 text-gray-600">
                <Phone className="w-5 h-5" />
                <span>{client.phone}</span>
              </div>
              <div className="flex items-center gap-3 text-gray-600">
                <Mail className="w-5 h-5" />
                <span>{client.email}</span>
              </div>
            </div>
          </div>

          {/* Visit Statistics */}
          <div className="grid grid-cols-3 gap-4">
            <div className="bg-[#F5E6F1] rounded-2xl p-6">
              <Calendar className="w-6 h-6 text-[#8B5A7C] mb-2" />
              <p className="text-sm text-gray-600 mb-1">Total Visits</p>
              <p className="text-2xl text-gray-900">{client.visits}</p>
            </div>
            <div className="bg-[#E8F4F8] rounded-2xl p-6">
              <DollarSign className="w-6 h-6 text-[#5A8B9E] mb-2" />
              <p className="text-sm text-gray-600 mb-1">Total Spent</p>
              <p className="text-2xl text-gray-900">$1,850</p>
            </div>
            <div className="bg-[#F0F4E8] rounded-2xl p-6">
              <Calendar className="w-6 h-6 text-[#6B8B5A] mb-2" />
              <p className="text-sm text-gray-600 mb-1">Last Visit</p>
              <p className="text-sm text-gray-900">{new Date(client.lastVisit).toLocaleDateString()}</p>
            </div>
          </div>

          {/* Recent Transactions */}
          <div>
            <h3 className="text-lg text-gray-900 mb-4">Recent Transactions</h3>
            <div className="space-y-3">
              {mockTransactions.map((transaction) => (
                <div
                  key={transaction.id}
                  className="bg-white border border-gray-100 rounded-2xl p-5 hover:shadow-sm transition-shadow"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-900 mb-1">{transaction.service}</p>
                      <div className="flex items-center gap-3 text-sm text-gray-500">
                        <span>{new Date(transaction.date).toLocaleDateString()}</span>
                        <span>•</span>
                        <span>Stylist: {transaction.stylist}</span>
                        <span
                          className={`px-3 py-1 rounded-full text-xs ${
                            transaction.status === 'completed'
                              ? 'bg-[#F0F4E8] text-[#6B8B5A]'
                              : 'bg-gray-100 text-gray-600'
                          }`}
                        >
                          {transaction.status}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <p className="text-lg text-gray-900">${transaction.amount.toFixed(2)}</p>
                      <button
                        onClick={() => handleRefund(transaction)}
                        className="p-2 hover:bg-red-50 rounded-xl transition-colors"
                        title="Process Refund"
                      >
                        <RefreshCcw className="w-5 h-5 text-red-600" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Refund Modal */}
        {showRefundModal && (
          <div className="absolute inset-0 bg-black/20 backdrop-blur-sm flex items-center justify-center rounded-3xl">
            <div className="bg-white rounded-2xl p-8 max-w-md w-full m-4">
              <h3 className="text-xl text-gray-900 mb-6">Process Refund</h3>
              <div className="space-y-4 mb-6">
                <div>
                  <label className="block text-sm text-gray-600 mb-2">
                    Partial Refund Amount
                  </label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400">
                      $
                    </span>
                    <input
                      type="number"
                      value={refundAmount}
                      onChange={(e) => setRefundAmount(e.target.value)}
                      placeholder="0.00"
                      step="0.01"
                      className="w-full pl-8 pr-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:border-[#8B5A7C]"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm text-gray-600 mb-2">Reason</label>
                  <textarea
                    value={refundReason}
                    onChange={(e) => setRefundReason(e.target.value)}
                    placeholder="Enter refund reason..."
                    rows={3}
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:border-[#8B5A7C] resize-none"
                  />
                </div>
              </div>
              <div className="flex gap-3">
                <button
                  onClick={() => processRefund('partial')}
                  disabled={!refundAmount || !refundReason}
                  className="flex-1 py-3 bg-[#8B5A7C] text-white rounded-xl hover:bg-[#7A4F6C] transition-colors disabled:opacity-50"
                >
                  Partial Refund
                </button>
                <button
                  onClick={() => processRefund('full')}
                  className="flex-1 py-3 bg-red-600 text-white rounded-xl hover:bg-red-700 transition-colors"
                >
                  Full Refund
                </button>
              </div>
              <button
                onClick={() => setShowRefundModal(false)}
                className="w-full mt-3 py-3 text-gray-600 hover:bg-gray-50 rounded-xl transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
