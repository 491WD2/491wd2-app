# Clean trash cans

Type: Chores
Status: Not started
Room: 🗑️ Trash & Recycling (https://www.notion.so/Trash-Recycling-2ef97e9c2a3181249089f3915f94b75c?pvs=21)
Completion %: 0%
Frequency: Weekly