# Disinfect door handles and light switches

Type: Chores
Status: Not started
Room: 🚽 Half Bath (https://www.notion.so/Half-Bath-2ef97e9c2a3181d881c4f8476b0304b8?pvs=21)
Completion %: 0%
Frequency: Weekly

### ✏️ Cleaning Description

---

Clean toilet seat and exterior weekly to disinfect and maintain bathroom hygiene.

---

### ✅ What I have to-do

---

- [ ]  Spray with disinfectant
- [ ]  Wipe seat, lid, and exterior
- [ ]  Clean base and behind toilet
- [ ]  Let disinfectant sit as directed

### ❌ What I need to avoid

---

- Missing the base and back
- Using same cloth for multiple areas
- Not letting disinfectant work

---