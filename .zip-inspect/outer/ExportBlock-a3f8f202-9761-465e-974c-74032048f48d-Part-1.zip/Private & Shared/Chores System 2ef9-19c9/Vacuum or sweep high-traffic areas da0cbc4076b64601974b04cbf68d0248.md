# Vacuum or sweep high-traffic areas

Type: Chores
Status: Not started
Room: 🚶 Halls (https://www.notion.so/Halls-2ef97e9c2a31812b92fed8399ea05356?pvs=21)
Completion %: 0%
Frequency: Daily

### ✏️ Cleaning Description

---

Vacuum or sweep high-traffic hallway areas to remove tracked-in dirt and dust.

---

### ✅ What I have to-do

---

- [ ]  Remove obstacles from floor
- [ ]  Vacuum or sweep main paths
- [ ]  Clean corners and edges
- [ ]  Check for sticky spots

### ❌ What I need to avoid

---

- Pushing dirt into other rooms
- Missing tight corners
- Ignoring baseboards

---