# Polish wood furniture

Type: Chores
Status: Not started
Room: 🍽️ Dining Room (https://www.notion.so/Dining-Room-2ef97e9c2a318192bdd0f0418b269200?pvs=21)
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Polish wood furniture in the dining room monthly to maintain finish and shine.

---

### ✅ What I have to-do

---

- [ ]  Dust furniture completely
- [ ]  Apply wood polish
- [ ]  Buff with clean cloth
- [ ]  Check for scratches

### ❌ What I need to avoid

---

- Using too much polish
- Polishing without dusting first
- Using wrong product for finish

---