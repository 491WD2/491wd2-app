# Wipe down baseboards

Type: Chores
Status: Not started
Room: 🚪 Entry (https://www.notion.so/Entry-2ef97e9c2a3181f78171fb35aa12d167?pvs=21)
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Wipe down entryway baseboards monthly to remove dirt and scuff marks.

---

### ✅ What I have to-do

---

- [ ]  Vacuum loose dirt first
- [ ]  Wipe with cleaning solution
- [ ]  Scrub scuffs gently
- [ ]  Dry completely

### ❌ What I need to avoid

---

- Using too much water
- Harsh scrubbing
- Missing corners

---