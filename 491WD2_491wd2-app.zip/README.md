
  # 491WD2/491wd2-app

  This is a code bundle for 491WD2/491wd2-app. The original project is available at https://www.figma.com/design/mdjDGIdr0EFIMFTQ4CWlmK/491WD2-491wd2-app.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  