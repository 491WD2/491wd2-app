import React, { useState } from 'react';
import { Plus, Search, AlertTriangle, TrendingDown, Package } from 'lucide-react';

export function StockView() {
  const [searchQuery, setSearchQuery] = useState('');

  const mockStock = [
    {
      id: 1,
      name: 'Keratin Treatment',
      category: 'Treatment',
      quantity: 12,
      minQuantity: 5,
      unit: 'bottles',
      lastRestocked: '2026-02-01',
      supplier: 'Beauty Supply Co.',
    },
    {
      id: 2,
      name: 'Hair Color - Blonde',
      category: 'Color',
      quantity: 3,
      minQuantity: 8,
      unit: 'boxes',
      lastRestocked: '2026-01-28',
      supplier: 'Color Pro',
    },
    {
      id: 3,
      name: 'Shampoo - Premium',
      category: 'Shampoo',
      quantity: 25,
      minQuantity: 10,
      unit: 'bottles',
      lastRestocked: '2026-02-05',
      supplier: 'Hair Care Inc.',
    },
    {
      id: 4,
      name: 'Conditioner - Deep',
      category: 'Conditioner',
      quantity: 18,
      minQuantity: 10,
      unit: 'bottles',
      lastRestocked: '2026-02-03',
      supplier: 'Hair Care Inc.',
    },
    {
      id: 5,
      name: 'Perm Solution',
      category: 'Perm',
      quantity: 6,
      minQuantity: 5,
      unit: 'kits',
      lastRestocked: '2026-01-30',
      supplier: 'Beauty Supply Co.',
    },
    {
      id: 6,
      name: 'Hair Mask - Repair',
      category: 'Treatment',
      quantity: 2,
      minQuantity: 6,
      unit: 'jars',
      lastRestocked: '2026-01-25',
      supplier: 'Premium Beauty',
    },
  ];

  const lowStock = mockStock.filter(item => item.quantity <= item.minQuantity);

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-3xl text-gray-900 mb-2">Stock Management</h2>
          <p className="text-gray-400">{mockStock.length} products in inventory</p>
        </div>
        <button className="flex items-center gap-2 px-6 py-3 bg-[#8B5A7C] text-white rounded-2xl hover:bg-[#7A4F6C] transition-colors">
          <Plus className="w-5 h-5" />
          <span>Add Product</span>
        </button>
      </div>

      {lowStock.length > 0 && (
        <div className="bg-[#FFF4E8] border border-[#FFE8D4] rounded-2xl p-6 mb-6">
          <div className="flex items-center gap-3 mb-4">
            <AlertTriangle className="w-5 h-5 text-[#8B7A5A]" />
            <h3 className="text-lg text-[#8B7A5A]">Low Stock Alert</h3>
          </div>
          <p className="text-sm text-gray-600">
            {lowStock.length} product{lowStock.length > 1 ? 's' : ''} running low on stock
          </p>
        </div>
      )}

      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search products..."
            className="w-full pl-14 pr-5 py-4 rounded-2xl border border-gray-200 bg-white focus:outline-none focus:border-[#8B5A7C] transition-colors"
          />
        </div>
      </div>

      <div className="grid gap-4">
        {mockStock.map((item) => {
          const isLowStock = item.quantity <= item.minQuantity;
          return (
            <div
              key={item.id}
              className="bg-white rounded-3xl p-6 hover:shadow-sm transition-shadow border border-gray-100"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-6">
                  <div className={`w-16 h-16 rounded-2xl flex items-center justify-center ${
                    isLowStock 
                      ? 'bg-[#FFF4E8]' 
                      : 'bg-gradient-to-br from-[#E8D5E8] to-[#D4C5E8]'
                  }`}>
                    <Package className={`w-8 h-8 ${
                      isLowStock ? 'text-[#8B7A5A]' : 'text-[#8B5A7C]'
                    }`} />
                  </div>
                  <div>
                    <h3 className="text-lg text-gray-900 mb-1">{item.name}</h3>
                    <div className="flex items-center gap-4 text-sm text-gray-500">
                      <span className="px-3 py-1 bg-gray-100 rounded-full">
                        {item.category}
                      </span>
                      <span>Supplier: {item.supplier}</span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="flex items-center gap-2 justify-end mb-2">
                    {isLowStock && (
                      <TrendingDown className="w-5 h-5 text-[#8B7A5A]" />
                    )}
                    <p className={`text-2xl ${
                      isLowStock ? 'text-[#8B7A5A]' : 'text-gray-900'
                    }`}>
                      {item.quantity}
                    </p>
                    <p className="text-gray-500">{item.unit}</p>
                  </div>
                  <p className="text-xs text-gray-400 mb-1">
                    Min: {item.minQuantity} {item.unit}
                  </p>
                  <p className="text-xs text-gray-400">
                    Last restocked: {new Date(item.lastRestocked).toLocaleDateString()}
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
