# Wash pillows and duvet

Type: Chores
Status: Not started
Room: 🛏️ Bedroom (https://www.notion.so/Bedroom-2ef97e9c2a318104bfe5c06efed42020?pvs=21)
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Wash pillows and duvet monthly to maintain freshness and remove allergens.

---

### ✅ What I have to-do

---

- [ ]  Check care labels
- [ ]  Wash per instructions
- [ ]  Dry completely before use
- [ ]  Fluff to restore shape

### ❌ What I need to avoid

---

- Ignoring care instructions
- Using too much detergent
- Not drying completely

---