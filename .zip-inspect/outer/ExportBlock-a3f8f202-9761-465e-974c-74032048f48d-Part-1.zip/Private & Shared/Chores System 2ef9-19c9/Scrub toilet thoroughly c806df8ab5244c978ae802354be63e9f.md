# Scrub toilet thoroughly

Type: Chores
Status: Not started
Room: 🚽 Half Bath (https://www.notion.so/Half-Bath-2ef97e9c2a3181d881c4f8476b0304b8?pvs=21)
Completion %: 0%
Frequency: Weekly

### ✏️ Cleaning Description

---

Wipe down bathroom cabinets weekly to remove dust and maintain cleanliness.

---

### ✅ What I have to-do

---

- [ ]  Wipe cabinet fronts
- [ ]  Clean handles and hardware
- [ ]  Remove any spills
- [ ]  Dry thoroughly

### ❌ What I need to avoid

---

- Using excess water on wood
- Missing handles
- Leaving streaks

---