# Vacuum high-traffic areas

Type: Chores
Status: Not started
Completion %: 0%
Frequency: Daily

### ✏️ Cleaning Description

---

Vacuum high-traffic areas like entryways and hallways to remove daily dirt and debris.

---

### ✅ What I have to-do

---

- [ ]  Clear floor of obstacles
- [ ]  Vacuum main walkways
- [ ]  Use attachments for corners
- [ ]  Empty vacuum if needed

### ❌ What I need to avoid

---

- Pushing dirt to other areas
- Using full vacuum bag
- Missing edges and corners

---