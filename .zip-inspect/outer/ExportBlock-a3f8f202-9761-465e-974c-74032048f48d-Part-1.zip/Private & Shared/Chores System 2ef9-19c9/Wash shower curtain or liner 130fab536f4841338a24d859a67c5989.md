# Wash shower curtain or liner

Type: Chores
Status: Not started
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Wash the shower curtain or liner monthly to prevent mold and mildew buildup.

---

### ✅ What I have to-do

---

- [ ]  Remove curtain or liner
- [ ]  Wash in machine with detergent
- [ ]  Add vinegar or bleach if needed
- [ ]  Hang to dry or rehang damp

### ❌ What I need to avoid

---

- Mixing bleach and vinegar
- Using hot water on vinyl
- Machine drying plastic liners

---