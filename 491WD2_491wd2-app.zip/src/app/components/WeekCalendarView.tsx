import React from 'react';

interface WeekCalendarViewProps {
  currentDate: Date;
  appointments: any[];
}

export function WeekCalendarView({ currentDate, appointments }: WeekCalendarViewProps) {
  const getWeekDays = () => {
    const week = [];
    const start = new Date(currentDate);
    start.setDate(start.getDate() - start.getDay()); // Start from Sunday
    
    for (let i = 0; i < 7; i++) {
      const day = new Date(start);
      day.setDate(start.getDate() + i);
      week.push(day);
    }
    return week;
  };

  const weekDays = getWeekDays();
  const hours = Array.from({ length: 12 }, (_, i) => i + 9); // 9 AM to 8 PM

  return (
    <div className="bg-white rounded-3xl border border-gray-100 overflow-hidden">
      {/* Week Header */}
      <div className="grid grid-cols-8 border-b border-gray-100">
        <div className="p-4 text-sm text-gray-500">Time</div>
        {weekDays.map((day, index) => {
          const isToday = day.toDateString() === new Date().toDateString();
          return (
            <div
              key={index}
              className={`p-4 text-center ${
                isToday ? 'bg-[#F5E6F1]' : ''
              }`}
            >
              <p className="text-sm text-gray-500">
                {day.toLocaleDateString('en-US', { weekday: 'short' })}
              </p>
              <p className={`text-lg mt-1 ${
                isToday ? 'text-[#8B5A7C] font-medium' : 'text-gray-900'
              }`}>
                {day.getDate()}
              </p>
            </div>
          );
        })}
      </div>

      {/* Time Grid */}
      <div className="overflow-auto max-h-[600px]">
        {hours.map((hour) => (
          <div key={hour} className="grid grid-cols-8 border-b border-gray-100">
            <div className="p-4 text-sm text-gray-500 border-r border-gray-100">
              {hour}:00
            </div>
            {weekDays.map((day, index) => (
              <div
                key={index}
                className="p-2 border-r border-gray-100 min-h-[80px] hover:bg-gray-50 transition-colors cursor-pointer"
              >
                {/* Mock appointments would be placed here */}
                {hour === 9 && index === 1 && (
                  <div className="bg-[#F5E6F1] rounded-xl p-2 text-xs">
                    <p className="text-[#8B5A7C] font-medium">Sarah Kim</p>
                    <p className="text-gray-600 mt-1">Hair Cut</p>
                  </div>
                )}
                {hour === 10 && index === 2 && (
                  <div className="bg-[#E8F4F8] rounded-xl p-2 text-xs">
                    <p className="text-[#5A8B9E] font-medium">Emma Lee</p>
                    <p className="text-gray-600 mt-1">Color Treatment</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}
