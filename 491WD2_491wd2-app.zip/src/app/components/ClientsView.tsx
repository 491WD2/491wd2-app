import React, { useState } from 'react';
import { Search, Plus, Phone, Mail } from 'lucide-react';
import { ClientDetailModal } from './ClientDetailModal';

export function ClientsView() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedClient, setSelectedClient] = useState<any>(null);

  const mockClients = [
    {
      id: 1,
      name: 'Sarah Kim',
      phone: '(555) 123-4567',
      email: 'sarah.kim@email.com',
      visits: 12,
      lastVisit: '2026-02-05',
    },
    {
      id: 2,
      name: 'Emma Lee',
      phone: '(555) 234-5678',
      email: 'emma.lee@email.com',
      visits: 8,
      lastVisit: '2026-02-08',
    },
    {
      id: 3,
      name: 'Jessica Park',
      phone: '(555) 345-6789',
      email: 'jessica.park@email.com',
      visits: 15,
      lastVisit: '2026-02-03',
    },
    {
      id: 4,
      name: 'Michelle Choi',
      phone: '(555) 456-7890',
      email: 'michelle.choi@email.com',
      visits: 5,
      lastVisit: '2026-01-28',
    },
  ];

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-3xl text-gray-900 mb-2">Clients</h2>
          <p className="text-gray-400">{mockClients.length} total clients</p>
        </div>
        <button className="flex items-center gap-2 px-6 py-3 bg-[#8B5A7C] text-white rounded-2xl hover:bg-[#7A4F6C] transition-colors">
          <Plus className="w-5 h-5" />
          <span>Add Client</span>
        </button>
      </div>

      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search clients..."
            className="w-full pl-14 pr-5 py-4 rounded-2xl border border-gray-200 bg-white focus:outline-none focus:border-[#8B5A7C] transition-colors"
          />
        </div>
      </div>

      <div className="grid gap-4">
        {mockClients.map((client) => (
          <div
            key={client.id}
            onClick={() => setSelectedClient(client)}
            className="bg-white rounded-3xl p-6 hover:shadow-sm transition-shadow border border-gray-100 cursor-pointer"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-6">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#E8D5E8] to-[#D4C5E8] flex items-center justify-center">
                  <span className="text-lg text-[#8B5A7C]">
                    {client.name
                      .split(' ')
                      .map((n) => n[0])
                      .join('')}
                  </span>
                </div>
                <div>
                  <h3 className="text-lg text-gray-900 mb-2">{client.name}</h3>
                  <div className="flex items-center gap-4 text-sm text-gray-500">
                    <div className="flex items-center gap-2">
                      <Phone className="w-4 h-4" />
                      <span>{client.phone}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Mail className="w-4 h-4" />
                      <span>{client.email}</span>
                    </div>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm text-gray-500 mb-1">Total Visits</p>
                <p className="text-2xl text-gray-900 mb-2">{client.visits}</p>
                <p className="text-xs text-gray-400">
                  Last visit: {new Date(client.lastVisit).toLocaleDateString()}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {selectedClient && (
        <ClientDetailModal
          client={selectedClient}
          onClose={() => setSelectedClient(null)}
        />
      )}
    </div>
  );
}