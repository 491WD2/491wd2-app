# Vacuum or mop entire hallway

Type: Chores
Status: Not started
Room: 🚶 Halls (https://www.notion.so/Halls-2ef97e9c2a31812b92fed8399ea05356?pvs=21)
Completion %: 0%
Frequency: Weekly