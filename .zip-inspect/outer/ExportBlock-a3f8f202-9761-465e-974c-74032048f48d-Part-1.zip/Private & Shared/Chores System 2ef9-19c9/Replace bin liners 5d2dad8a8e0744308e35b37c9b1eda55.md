# Replace bin liners

Type: Chores
Status: Not started
Room: 🗑️ Trash & Recycling (https://www.notion.so/Trash-Recycling-2ef97e9c2a3181249089f3915f94b75c?pvs=21)
Completion %: 0%
Frequency: Weekly

### ✏️ Cleaning Description

---

Vacuum living room floor weekly to remove dirt, dust, and debris.

---

### ✅ What I have to-do

---

- [ ]  Clear floor of items
- [ ]  Vacuum entire room
- [ ]  Get under furniture
- [ ]  Use edge tool for baseboards

### ❌ What I need to avoid

---

- Missing under couches
- Using full vacuum
- Skipping corners

---