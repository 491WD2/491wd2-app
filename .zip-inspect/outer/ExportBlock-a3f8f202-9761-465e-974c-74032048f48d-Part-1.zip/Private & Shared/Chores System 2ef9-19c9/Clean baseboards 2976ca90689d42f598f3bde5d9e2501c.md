# Clean baseboards

Type: Chores
Status: Not started
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Clean baseboards throughout the room to remove dust, dirt, and scuff marks.

---

### ✅ What I have to-do

---

- [ ]  Vacuum or dust baseboards first
- [ ]  Wipe with damp cloth
- [ ]  Scrub scuff marks gently
- [ ]  Dry thoroughly

### ❌ What I need to avoid

---

- Using too much water
- Scratching paint with abrasives
- Missing corners and behind doors

---