# Dust picture frames and decor

Type: Chores
Status: Not started
Room: 🚶 Halls (https://www.notion.so/Halls-2ef97e9c2a31812b92fed8399ea05356?pvs=21)
Completion %: 0%
Frequency: Weekly

### ✏️ Cleaning Description

---

Dust hallway surfaces weekly including any tables, frames, and decor.

---

### ✅ What I have to-do

---

- [ ]  Dust from ceiling down
- [ ]  Clean all horizontal surfaces
- [ ]  Dust picture frames
- [ ]  Wipe light switches

### ❌ What I need to avoid

---

- Leaving dust on frames
- Missing tops of doorframes
- Using dirty cloth

---