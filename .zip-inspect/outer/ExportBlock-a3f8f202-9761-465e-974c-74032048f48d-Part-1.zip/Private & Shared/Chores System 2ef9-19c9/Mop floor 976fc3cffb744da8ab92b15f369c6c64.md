# Mop floor

Type: Chores
Status: Not started
Room: 🚪 Entry (https://www.notion.so/Entry-2ef97e9c2a3181f78171fb35aa12d167?pvs=21)
Completion %: 0%
Frequency: Weekly

### ✏️ Cleaning Description

---

Dust entryway furniture and surfaces weekly to maintain a welcoming entrance.

---

### ✅ What I have to-do

---

- [ ]  Dust console or entry table
- [ ]  Clean any shelves or hooks
- [ ]  Dust picture frames
- [ ]  Wipe down surfaces

### ❌ What I need to avoid

---

- Missing tops of frames
- Leaving dust on decor
- Using dirty cloths

---