# Wash dishes or load dishwasher

Type: Chores
Status: Not started
Completion %: 0%
Frequency: Daily

### ✏️ Cleaning Description

---

Wash all dirty dishes by hand or load them into the dishwasher properly for cleaning.

---

### ✅ What I have to-do

---

- [ ]  Scrape off food scraps
- [ ]  Rinse dishes
- [ ]  Load dishwasher or hand wash
- [ ]  Put away clean dishes

### ❌ What I need to avoid

---

- Overloading the dishwasher
- Leaving dishes in sink overnight
- Putting non-dishwasher safe items in machine

---