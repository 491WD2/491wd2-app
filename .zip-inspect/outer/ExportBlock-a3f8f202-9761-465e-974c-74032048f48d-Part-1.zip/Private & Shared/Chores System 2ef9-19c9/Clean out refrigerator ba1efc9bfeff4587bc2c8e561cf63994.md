# Clean out refrigerator

Type: Chores
Status: Not started
Completion %: 0%
Frequency: Weekly

### ✏️ Cleaning Description

---

Clean out the refrigerator, removing expired items and wiping down shelves and drawers.

---

### ✅ What I have to-do

---

- [ ]  Check expiration dates
- [ ]  Remove expired items
- [ ]  Wipe down shelves and drawers
- [ ]  Organize remaining items
- [ ]  Check temperature setting

### ❌ What I need to avoid

---

- Leaving door open too long
- Using too much water
- Putting items back before cleaning

---