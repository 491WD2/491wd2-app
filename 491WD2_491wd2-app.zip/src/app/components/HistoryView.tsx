import React, { useState } from 'react';
import { Search, Filter, RefreshCcw, DollarSign } from 'lucide-react';

export function HistoryView() {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState('all');

  const mockHistory = [
    {
      id: 1,
      type: 'payment',
      client: 'Sarah Kim',
      service: 'Hair Cut & Style',
      amount: 125.0,
      paymentMethod: 'Card',
      date: '2026-02-08 09:45',
      status: 'completed',
    },
    {
      id: 2,
      type: 'refund',
      client: 'Emma Lee',
      service: 'Color Treatment',
      amount: -80.0,
      paymentMethod: 'Card',
      date: '2026-02-07 14:30',
      status: 'refunded',
      reason: 'Client dissatisfaction',
    },
    {
      id: 3,
      type: 'payment',
      client: 'Jessica Park',
      service: 'Hair Perm',
      amount: 195.0,
      paymentMethod: 'Cash',
      date: '2026-02-07 10:15',
      status: 'completed',
    },
    {
      id: 4,
      type: 'partial-refund',
      client: 'Michelle Choi',
      service: 'Treatment & Styling',
      amount: -50.0,
      paymentMethod: 'Voucher',
      date: '2026-02-06 16:20',
      status: 'partial-refund',
      reason: 'Service adjustment',
    },
    {
      id: 5,
      type: 'payment',
      client: 'Lisa Yoon',
      service: 'Highlights',
      amount: 220.0,
      paymentMethod: 'Card',
      date: '2026-02-06 11:00',
      status: 'completed',
    },
    {
      id: 6,
      type: 'payment',
      client: 'Walk-In Customer',
      service: 'Hair Cut',
      amount: 85.0,
      paymentMethod: 'Cash',
      date: '2026-02-05 15:30',
      status: 'completed',
    },
  ];

  const filteredHistory = mockHistory.filter(item => {
    if (filterType === 'all') return true;
    if (filterType === 'refunds') return item.type === 'refund' || item.type === 'partial-refund';
    if (filterType === 'payments') return item.type === 'payment';
    return true;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-[#F0F4E8] text-[#6B8B5A]';
      case 'refunded':
        return 'bg-red-50 text-red-600';
      case 'partial-refund':
        return 'bg-[#FFF4E8] text-[#8B7A5A]';
      default:
        return 'bg-gray-100 text-gray-600';
    }
  };

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-3xl text-gray-900 mb-2">Transaction History</h2>
          <p className="text-gray-400">{mockHistory.length} total transactions</p>
        </div>
      </div>

      <div className="flex gap-4 mb-6">
        <div className="flex-1 relative">
          <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search transactions..."
            className="w-full pl-14 pr-5 py-4 rounded-2xl border border-gray-200 bg-white focus:outline-none focus:border-[#8B5A7C] transition-colors"
          />
        </div>
        <div className="flex gap-2 bg-white rounded-2xl p-1 border border-gray-200">
          <button
            onClick={() => setFilterType('all')}
            className={`px-6 py-3 rounded-xl transition-colors ${
              filterType === 'all'
                ? 'bg-[#F5E6F1] text-[#8B5A7C]'
                : 'text-gray-500 hover:bg-gray-50'
            }`}
          >
            All
          </button>
          <button
            onClick={() => setFilterType('payments')}
            className={`px-6 py-3 rounded-xl transition-colors ${
              filterType === 'payments'
                ? 'bg-[#F5E6F1] text-[#8B5A7C]'
                : 'text-gray-500 hover:bg-gray-50'
            }`}
          >
            Payments
          </button>
          <button
            onClick={() => setFilterType('refunds')}
            className={`px-6 py-3 rounded-xl transition-colors ${
              filterType === 'refunds'
                ? 'bg-[#F5E6F1] text-[#8B5A7C]'
                : 'text-gray-500 hover:bg-gray-50'
            }`}
          >
            Refunds
          </button>
        </div>
      </div>

      <div className="grid gap-4">
        {filteredHistory.map((item) => (
          <div
            key={item.id}
            className="bg-white rounded-3xl p-6 hover:shadow-sm transition-shadow border border-gray-100"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-6">
                <div className={`w-16 h-16 rounded-2xl flex items-center justify-center ${
                  item.type === 'payment' 
                    ? 'bg-gradient-to-br from-[#E8D5E8] to-[#D4C5E8]'
                    : 'bg-red-50'
                }`}>
                  {item.type === 'payment' ? (
                    <DollarSign className="w-8 h-8 text-[#8B5A7C]" />
                  ) : (
                    <RefreshCcw className="w-8 h-8 text-red-600" />
                  )}
                </div>
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-lg text-gray-900">{item.client}</h3>
                    <span className={`px-3 py-1 rounded-full text-xs ${getStatusColor(item.status)}`}>
                      {item.status === 'partial-refund' ? 'Partial Refund' : item.status.charAt(0).toUpperCase() + item.status.slice(1)}
                    </span>
                  </div>
                  <p className="text-gray-500 mb-1">{item.service}</p>
                  <div className="flex items-center gap-4 text-sm text-gray-400">
                    <span>{item.paymentMethod}</span>
                    <span>•</span>
                    <span>{item.date}</span>
                  </div>
                  {item.reason && (
                    <p className="text-sm text-gray-500 mt-2">Reason: {item.reason}</p>
                  )}
                </div>
              </div>
              <div className="text-right">
                <p className={`text-2xl ${
                  item.amount < 0 ? 'text-red-600' : 'text-gray-900'
                }`}>
                  {item.amount < 0 ? '-' : ''}${Math.abs(item.amount).toFixed(2)}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
