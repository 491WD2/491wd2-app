# Clean exhaust fan

Type: Chores
Status: Not started
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Clean the bathroom exhaust fan monthly to remove dust and improve air circulation.

---

### ✅ What I have to-do

---

- [ ]  Turn off power to fan
- [ ]  Remove fan cover
- [ ]  Vacuum dust from fan and cover
- [ ]  Wipe and replace cover

### ❌ What I need to avoid

---

- Cleaning while power is on
- Using water near electrical parts
- Forcing fan blades

---