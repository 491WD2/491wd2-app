# Clean light fixtures and ceiling fan

Type: Chores
Status: Not started
Room: 👨‍👩‍👧‍👦 Family Room (https://www.notion.so/Family-Room-2ef97e9c2a3181c7b087f2438a1f9bf9?pvs=21)
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Clean family room light fixtures and ceiling fan monthly to remove dust buildup.

---

### ✅ What I have to-do

---

- [ ]  Turn off power and cool down
- [ ]  Dust all fan blades
- [ ]  Remove and clean light covers
- [ ]  Wipe fan body and motor cover

### ❌ What I need to avoid

---

- Cleaning while in operation
- Spraying water on electrical parts
- Applying too much pressure on blades

---