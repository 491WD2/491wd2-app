# Clean light fixtures and ceiling fan

Type: Chores
Status: Not started
Room: 🛏️ Bedroom (https://www.notion.so/Bedroom-2ef97e9c2a318104bfe5c06efed42020?pvs=21)
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Clean bedroom light fixtures and ceiling fan monthly to remove dust and improve air quality.

---

### ✅ What I have to-do

---

- [ ]  Turn off and let cool
- [ ]  Dust fan blades thoroughly
- [ ]  Clean light fixture covers
- [ ]  Wipe fan motor housing

### ❌ What I need to avoid

---

- Cleaning while running
- Using water near motor
- Bending fan blades

---