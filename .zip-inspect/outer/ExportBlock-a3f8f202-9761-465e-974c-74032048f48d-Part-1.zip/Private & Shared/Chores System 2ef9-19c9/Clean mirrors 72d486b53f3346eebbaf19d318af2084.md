# Clean mirrors

Type: Chores
Status: Not started
Completion %: 0%
Frequency: Weekly

### ✏️ Cleaning Description

---

Clean all mirrors weekly to maintain clear, streak-free reflection.

---

### ✅ What I have to-do

---

- [ ]  Spray with glass cleaner
- [ ]  Wipe in circular motion
- [ ]  Buff dry with clean cloth
- [ ]  Check for missed spots

### ❌ What I need to avoid

---

- Leaving streaks or smudges
- Using dirty cloths
- Spraying too much cleaner

---