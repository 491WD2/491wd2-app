# Wipe down walls and door

Type: Chores
Status: Not started
Room: 🥫 Pantry (https://www.notion.so/Pantry-2ef97e9c2a3181979138c282576cd910?pvs=21)
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Wipe down pantry walls and door monthly to remove dust and food residue.

---

### ✅ What I have to-do

---

- [ ]  Dust all wall surfaces
- [ ]  Wipe with all-purpose cleaner
- [ ]  Clean door inside and out
- [ ]  Dry completely

### ❌ What I need to avoid

---

- Leaving sticky spots
- Over-wetting surfaces
- Missing door edges

---