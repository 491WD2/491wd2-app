# Put away clothes

Type: Chores
Status: Not started
Room: 🛏️ Bedroom (https://www.notion.so/Bedroom-2ef97e9c2a318104bfe5c06efed42020?pvs=21)
Completion %: 0%
Frequency: Daily

### ✏️ Cleaning Description

---

Put away clothes in closets and drawers to keep the bedroom tidy and organized.

---

### ✅ What I have to-do

---

- [ ]  Gather clothes from chairs and floor
- [ ]  Sort dirty clothes to hamper
- [ ]  Fold and put away clean clothes
- [ ]  Hang items that need hanging

### ❌ What I need to avoid

---

- Leaving clothes draped over furniture
- Mixing clean and dirty clothes
- Stuffing drawers without folding

---