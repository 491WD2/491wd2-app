# Deep clean chandelier or light fixture

Type: Chores
Status: Not started
Room: 🍽️ Dining Room (https://www.notion.so/Dining-Room-2ef97e9c2a318192bdd0f0418b269200?pvs=21)
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Deep clean the dining room chandelier or light fixture monthly for maximum sparkle.

---

### ✅ What I have to-do

---

- [ ]  Turn off power at breaker
- [ ]  Remove crystals or parts
- [ ]  Wash in soapy water
- [ ]  Dry and reassemble carefully

### ❌ What I need to avoid

---

- Cleaning with power on
- Dropping delicate parts
- Using abrasive cleaners

---