# Clean toilet bowl

Type: Chores
Status: Not started
Completion %: 0%
Frequency: Daily

### ✏️ Cleaning Description

Clean and sanitize the toilet bowl thoroughly, removing stains, mineral buildup, and bacteria for a hygienic bathroom.

---

### 📋 Step-by-Step Instructions

- [ ]  Put on cleaning gloves for protection
- [ ]  Apply toilet bowl cleaner under the rim
- [ ]  Squeeze cleaner around entire bowl surface
- [ ]  Let cleaner sit for 5-10 minutes to work
- [ ]  Use toilet brush to scrub entire bowl
- [ ]  Scrub thoroughly under the rim where stains hide
- [ ]  Scrub waterline area where rings form
- [ ]  Flush toilet to rinse away cleaner
- [ ]  Rinse brush in clean toilet water

### ⚠️ Important Safety & Mistakes to Avoid

- Never mix toilet bowl cleaner with bleach or other products
- Don't use abrasive scrubbers that can scratch the porcelain
- Never forget to clean under the rim where bacteria hide
- Avoid splashing cleaner on skin or in eyes
- Don't leave toilet brush sitting in dirty water

---