# Deep clean carpets or mop floors

Type: Chores
Status: Not started
Room: 👨‍👩‍👧‍👦 Family Room (https://www.notion.so/Family-Room-2ef97e9c2a3181c7b087f2438a1f9bf9?pvs=21)
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Deep clean family room carpets or mop floors monthly to remove embedded dirt.

---

### ✅ What I have to-do

---

- [ ]  Move furniture if possible
- [ ]  Vacuum or sweep thoroughly
- [ ]  Deep clean with machine or mop
- [ ]  Let dry before replacing furniture

### ❌ What I need to avoid

---

- Using too much water
- Skipping corners under furniture
- Rushing the drying process

---