import React, { useState } from 'react';
import { LogOut, Clock, Bell, DollarSign, Printer, Mail } from 'lucide-react';

export function SettingsView() {
  const [businessHours, setBusinessHours] = useState({
    open: '09:00',
    close: '18:00',
  });
  const [emailReminders, setEmailReminders] = useState(true);
  const [smsReminders, setSmsReminders] = useState(true);
  const [reminderTime, setReminderTime] = useState('24'); // hours before

  const handleLogout = () => {
    // Logout logic here
    alert('Logout functionality would be implemented here');
  };

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <div className="mb-8">
        <h2 className="text-3xl text-gray-900 mb-2">Settings</h2>
        <p className="text-gray-400">Manage your salon preferences</p>
      </div>

      <div className="space-y-6">
        {/* Business Hours */}
        <div className="bg-white rounded-3xl p-6 border border-gray-100">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#E8D5E8] to-[#D4C5E8] flex items-center justify-center">
              <Clock className="w-6 h-6 text-[#8B5A7C]" />
            </div>
            <div>
              <h3 className="text-lg text-gray-900">Business Hours</h3>
              <p className="text-sm text-gray-500">Set your operating hours</p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm text-gray-600 mb-2">Opening Time</label>
              <input
                type="time"
                value={businessHours.open}
                onChange={(e) => setBusinessHours({ ...businessHours, open: e.target.value })}
                className="w-full px-4 py-3 rounded-2xl border border-gray-200 focus:outline-none focus:border-[#8B5A7C] transition-colors"
              />
            </div>
            <div>
              <label className="block text-sm text-gray-600 mb-2">Closing Time</label>
              <input
                type="time"
                value={businessHours.close}
                onChange={(e) => setBusinessHours({ ...businessHours, close: e.target.value })}
                className="w-full px-4 py-3 rounded-2xl border border-gray-200 focus:outline-none focus:border-[#8B5A7C] transition-colors"
              />
            </div>
          </div>
        </div>

        {/* Appointment Reminders */}
        <div className="bg-white rounded-3xl p-6 border border-gray-100">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#E8F4F8] to-[#D4E5F8] flex items-center justify-center">
              <Bell className="w-6 h-6 text-[#5A8B9E]" />
            </div>
            <div>
              <h3 className="text-lg text-gray-900">Appointment Reminders</h3>
              <p className="text-sm text-gray-500">Automatic notifications for clients</p>
            </div>
          </div>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-2xl">
              <div className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-gray-500" />
                <div>
                  <p className="text-gray-900">Email Reminders</p>
                  <p className="text-sm text-gray-500">Send email notifications</p>
                </div>
              </div>
              <button
                onClick={() => setEmailReminders(!emailReminders)}
                className={`relative w-14 h-8 rounded-full transition-colors ${
                  emailReminders ? 'bg-[#8B5A7C]' : 'bg-gray-300'
                }`}
              >
                <span
                  className={`absolute top-1 w-6 h-6 bg-white rounded-full transition-transform ${
                    emailReminders ? 'translate-x-7' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-2xl">
              <div className="flex items-center gap-3">
                <Bell className="w-5 h-5 text-gray-500" />
                <div>
                  <p className="text-gray-900">SMS Reminders</p>
                  <p className="text-sm text-gray-500">Send text notifications</p>
                </div>
              </div>
              <button
                onClick={() => setSmsReminders(!smsReminders)}
                className={`relative w-14 h-8 rounded-full transition-colors ${
                  smsReminders ? 'bg-[#8B5A7C]' : 'bg-gray-300'
                }`}
              >
                <span
                  className={`absolute top-1 w-6 h-6 bg-white rounded-full transition-transform ${
                    smsReminders ? 'translate-x-7' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            <div>
              <label className="block text-sm text-gray-600 mb-2">Send reminder before</label>
              <select
                value={reminderTime}
                onChange={(e) => setReminderTime(e.target.value)}
                className="w-full px-4 py-3 rounded-2xl border border-gray-200 focus:outline-none focus:border-[#8B5A7C] transition-colors"
              >
                <option value="1">1 hour</option>
                <option value="2">2 hours</option>
                <option value="6">6 hours</option>
                <option value="24">24 hours (1 day)</option>
                <option value="48">48 hours (2 days)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Payment Settings */}
        <div className="bg-white rounded-3xl p-6 border border-gray-100">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#F0F4E8] to-[#E5F0D4] flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-[#6B8B5A]" />
            </div>
            <div>
              <h3 className="text-lg text-gray-900">Payment Settings</h3>
              <p className="text-sm text-gray-500">Configure payment options</p>
            </div>
          </div>
          <div className="space-y-3">
            <div className="flex items-center justify-between text-sm text-gray-600">
              <span>GST Rate</span>
              <span className="text-gray-900">10%</span>
            </div>
            <div className="flex items-center justify-between text-sm text-gray-600">
              <span>Weekend Surcharge</span>
              <span className="text-gray-900">15%</span>
            </div>
            <div className="flex items-center justify-between text-sm text-gray-600">
              <span>Accepted Payment Methods</span>
              <span className="text-gray-900">Cash, Card, Voucher</span>
            </div>
          </div>
        </div>

        {/* Receipt Settings */}
        <div className="bg-white rounded-3xl p-6 border border-gray-100">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#FFF4E8] to-[#FFE8D4] flex items-center justify-center">
              <Printer className="w-6 h-6 text-[#8B7A5A]" />
            </div>
            <div>
              <h3 className="text-lg text-gray-900">Receipt Settings</h3>
              <p className="text-sm text-gray-500">Default receipt options</p>
            </div>
          </div>
          <p className="text-sm text-gray-600">
            Receipts can be printed or emailed after each transaction
          </p>
        </div>

        {/* Logout */}
        <div className="bg-white rounded-3xl p-6 border border-gray-100">
          <button
            onClick={handleLogout}
            className="w-full flex items-center justify-center gap-3 px-6 py-4 bg-red-50 text-red-600 rounded-2xl hover:bg-red-100 transition-colors"
          >
            <LogOut className="w-5 h-5" />
            <span className="font-medium">Log Out</span>
          </button>
        </div>
      </div>
    </div>
  );
}
