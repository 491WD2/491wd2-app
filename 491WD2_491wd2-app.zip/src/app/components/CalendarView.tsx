import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Plus, DollarSign, Calendar as CalendarIcon, List, Edit2 } from 'lucide-react';
import { WeekCalendarView } from './WeekCalendarView';
import { MonthCalendarView } from './MonthCalendarView';
import { EditAppointmentModal } from './EditAppointmentModal';

interface CalendarViewProps {
  onQuickCheckout: (appointment?: any) => void;
}

export function CalendarView({ onQuickCheckout }: CalendarViewProps) {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [viewMode, setViewMode] = useState<'list' | 'week' | 'month'>('list');
  const [editingAppointment, setEditingAppointment] = useState<any>(null);

  const mockAppointments = [
    {
      id: 1,
      time: '09:00',
      client: 'Sarah Kim',
      service: 'Hair Cut & Style',
      stylist: 'Jenny',
      duration: '60 min',
      status: 'confirmed',
    },
    {
      id: 2,
      time: '10:30',
      client: 'Emma Lee',
      service: 'Color Treatment',
      stylist: 'Min',
      duration: '120 min',
      status: 'in-progress',
    },
    {
      id: 3,
      time: '13:00',
      client: 'Jessica Park',
      service: 'Hair Perm',
      stylist: 'Jenny',
      duration: '90 min',
      status: 'confirmed',
    },
    {
      id: 4,
      time: '15:00',
      client: 'Michelle Choi',
      service: 'Treatment & Styling',
      stylist: 'Soo',
      duration: '75 min',
      status: 'confirmed',
    },
  ];

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const changeDay = (direction: number) => {
    const newDate = new Date(currentDate);
    newDate.setDate(newDate.getDate() + direction);
    setCurrentDate(newDate);
  };

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-3xl text-gray-900 mb-2">
            {viewMode === 'list' ? "Today's Schedule" : 'Calendar'}
          </h2>
          <p className="text-gray-400">{formatDate(currentDate)}</p>
        </div>
        <div className="flex items-center gap-4">
          {/* View Mode Selector */}
          <div className="flex gap-2 bg-white rounded-2xl p-1 border border-gray-200">
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 rounded-xl transition-colors ${
                viewMode === 'list'
                  ? 'bg-[#F5E6F1] text-[#8B5A7C]'
                  : 'text-gray-500 hover:bg-gray-50'
              }`}
              title="List View"
            >
              <List className="w-5 h-5" />
            </button>
            <button
              onClick={() => setViewMode('week')}
              className={`p-2 rounded-xl transition-colors ${
                viewMode === 'week'
                  ? 'bg-[#F5E6F1] text-[#8B5A7C]'
                  : 'text-gray-500 hover:bg-gray-50'
              }`}
              title="Week View"
            >
              <CalendarIcon className="w-5 h-5" />
            </button>
            <button
              onClick={() => setViewMode('month')}
              className={`p-2 rounded-xl transition-colors ${
                viewMode === 'month'
                  ? 'bg-[#F5E6F1] text-[#8B5A7C]'
                  : 'text-gray-500 hover:bg-gray-50'
              }`}
              title="Month View"
            >
              <CalendarIcon className="w-5 h-5" />
            </button>
          </div>

          <div className="flex items-center gap-2 bg-white rounded-2xl p-1">
            <button
              onClick={() => changeDay(-1)}
              className="p-2 hover:bg-gray-50 rounded-xl transition-colors"
            >
              <ChevronLeft className="w-5 h-5 text-gray-600" />
            </button>
            <button
              onClick={() => setCurrentDate(new Date())}
              className="px-4 py-2 text-sm text-gray-600 hover:bg-gray-50 rounded-xl transition-colors"
            >
              Today
            </button>
            <button
              onClick={() => changeDay(1)}
              className="p-2 hover:bg-gray-50 rounded-xl transition-colors"
            >
              <ChevronRight className="w-5 h-5 text-gray-600" />
            </button>
          </div>
          <button className="flex items-center gap-2 px-6 py-3 bg-[#8B5A7C] text-white rounded-2xl hover:bg-[#7A4F6C] transition-colors">
            <Plus className="w-5 h-5" />
            <span>New Appointment</span>
          </button>
          <button
            onClick={() => onQuickCheckout()}
            className="flex items-center gap-2 px-6 py-3 bg-[#E8F4F8] text-[#5A8B9E] rounded-2xl hover:bg-[#D4E5F8] transition-colors"
          >
            <DollarSign className="w-5 h-5" />
            <span>Walk-In Checkout</span>
          </button>
        </div>
      </div>

      {viewMode === 'list' ? (
        <div className="grid gap-4">
          {mockAppointments.map((appointment) => (
            <div
              key={appointment.id}
              className="bg-white rounded-3xl p-6 hover:shadow-sm transition-shadow border border-gray-100"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-6">
                  <div className="text-center min-w-[80px]">
                    <p className="text-2xl text-gray-900">{appointment.time}</p>
                    <p className="text-sm text-gray-400 mt-1">
                      {appointment.duration}
                    </p>
                  </div>
                  <div className="h-12 w-px bg-gray-100" />
                  <div>
                    <h3 className="text-lg text-gray-900 mb-1">
                      {appointment.client}
                    </h3>
                    <p className="text-gray-500 mb-2">{appointment.service}</p>
                    <div className="flex items-center gap-3">
                      <span className="text-sm text-gray-400">
                        Stylist: {appointment.stylist}
                      </span>
                      <span
                        className={`px-3 py-1 rounded-full text-xs ${
                          appointment.status === 'in-progress'
                            ? 'bg-[#E8F4F8] text-[#5A8B9E]'
                            : 'bg-[#F0F4E8] text-[#6B8B5A]'
                        }`}
                      >
                        {appointment.status === 'in-progress'
                          ? 'In Progress'
                          : 'Confirmed'}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setEditingAppointment(appointment)}
                    className="p-3 bg-gray-50 text-gray-600 rounded-2xl hover:bg-gray-100 transition-colors"
                    title="Edit Appointment"
                  >
                    <Edit2 className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => onQuickCheckout(appointment)}
                    className="px-8 py-3 bg-[#F5E6F1] text-[#8B5A7C] rounded-2xl hover:bg-[#EDD9E8] transition-colors"
                  >
                    Quick Checkout
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : viewMode === 'week' ? (
        <WeekCalendarView currentDate={currentDate} appointments={mockAppointments} />
      ) : (
        <MonthCalendarView currentDate={currentDate} appointments={mockAppointments} />
      )}

      {editingAppointment && (
        <EditAppointmentModal
          appointment={editingAppointment}
          onClose={() => setEditingAppointment(null)}
          onSave={(updated) => {
            console.log('Updated appointment:', updated);
            setEditingAppointment(null);
          }}
        />
      )}
    </div>
  );
}
