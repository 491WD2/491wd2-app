# Change bed linens

Type: Chores
Status: Not started
Room: 🛏️ Bedroom (https://www.notion.so/Bedroom-2ef97e9c2a318104bfe5c06efed42020?pvs=21)
Completion %: 0%
Frequency: Weekly

### ✏️ Cleaning Description

---

Change bed linens weekly for fresh, clean bedding and improved sleep hygiene.

---

### ✅ What I have to-do

---

- [ ]  Strip all sheets and pillowcases
- [ ]  Wash bedding in hot water
- [ ]  Dry completely
- [ ]  Make bed with fresh linens

### ❌ What I need to avoid

---

- Waiting more than a week
- Using damp sheets
- Skipping pillowcases

---