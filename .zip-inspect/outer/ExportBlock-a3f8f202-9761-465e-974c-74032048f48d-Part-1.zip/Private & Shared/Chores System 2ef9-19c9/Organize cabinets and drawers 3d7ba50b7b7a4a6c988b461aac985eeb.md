# Organize cabinets and drawers

Type: Chores
Status: Not started
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Organize bathroom cabinets and drawers monthly, discarding expired items.

---

### ✅ What I have to-do

---

- [ ]  Remove all items
- [ ]  Wipe shelves and drawers
- [ ]  Check expiration dates
- [ ]  Reorganize by category

### ❌ What I need to avoid

---

- Keeping expired products
- Overcrowding spaces
- Poor organization system

---