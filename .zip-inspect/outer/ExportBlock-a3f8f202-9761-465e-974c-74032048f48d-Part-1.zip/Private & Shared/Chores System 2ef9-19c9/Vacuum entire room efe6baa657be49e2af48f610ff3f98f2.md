# Vacuum entire room

Type: Chores
Status: Not started
Room: 👨‍👩‍👧‍👦 Family Room (https://www.notion.so/Family-Room-2ef97e9c2a3181c7b087f2438a1f9bf9?pvs=21)
Completion %: 0%
Frequency: Weekly

### ✏️ Cleaning Description

---

Wipe kitchen appliances weekly to remove fingerprints, spills, and grease.

---

### ✅ What I have to-do

---

- [ ]  Wipe refrigerator exterior
- [ ]  Clean stove and oven front
- [ ]  Wipe dishwasher front
- [ ]  Clean small appliances

### ❌ What I need to avoid

---

- Using abrasives on stainless
- Missing appliance sides
- Leaving streaks

---