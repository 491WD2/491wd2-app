# Clean refrigerator coils

Type: Chores
Status: Not started
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Clean refrigerator coils monthly to improve efficiency and prevent overheating.

---

### ✅ What I have to-do

---

- [ ]  Unplug refrigerator
- [ ]  Pull fridge away from wall
- [ ]  Vacuum coils with brush attachment
- [ ]  Replace and plug back in

### ❌ What I need to avoid

---

- Cleaning while plugged in
- Bending coils
- Using water on coils

---