# Take bins to curb for pickup

Type: Chores
Status: Not started
Room: 🗑️ Trash & Recycling (https://www.notion.so/Trash-Recycling-2ef97e9c2a3181249089f3915f94b75c?pvs=21)
Completion %: 0%
Frequency: Weekly

### ✏️ Cleaning Description

---

Wipe down door handles weekly to disinfect high-touch surfaces.

---

### ✅ What I have to-do

---

- [ ]  Wipe all door handles
- [ ]  Use disinfectant
- [ ]  Get both sides of each handle
- [ ]  Don't forget cabinet handles

### ❌ What I need to avoid

---

- Missing any handles
- Using cleaner that damages finish
- Not letting disinfectant work

---