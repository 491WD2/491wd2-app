# Take out recycling

Type: Chores
Status: Not started
Room: 🗑️ Trash & Recycling (https://www.notion.so/Trash-Recycling-2ef97e9c2a3181249089f3915f94b75c?pvs=21)
Completion %: 0%
Frequency: Weekly

### ✏️ Cleaning Description

---

Wipe down light switches weekly to remove fingerprints and germs.

---

### ✅ What I have to-do

---

- [ ]  Wipe all light switches
- [ ]  Use disinfectant wipe or spray
- [ ]  Clean switch plates too
- [ ]  Get all rooms

### ❌ What I need to avoid

---

- Spraying directly on switches
- Missing any switches
- Leaving moisture

---