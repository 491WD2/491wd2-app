# Fluff cushions and fold throws

Type: Chores
Status: Not started
Completion %: 0%
Frequency: Daily

### ✏️ Cleaning Description

Fluff couch cushions and neatly fold throw blankets for a tidy, inviting living space that looks organized and comfortable.

---

### 📋 Step-by-Step Instructions

- [ ]  Remove all cushions from furniture
- [ ]  Vacuum underneath cushions and base
- [ ]  Fluff each cushion vigorously by hand
- [ ]  Rotate cushions to distribute wear evenly
- [ ]  Replace cushions neatly on furniture
- [ ]  Gather all throw blankets from furniture
- [ ]  Fold each blanket neatly and uniformly
- [ ]  Drape or arrange throws attractively
- [ ]  Step back and check overall appearance

### ⚠️ Important Safety & Mistakes to Avoid

- Don't leave cushions flat or misshapen
- Avoid bunching throws sloppily on furniture
- Never ignore visible stains or spills on fabrics
- Don't forget to vacuum debris from under cushions
- Avoid inconsistent folding that looks messy

---