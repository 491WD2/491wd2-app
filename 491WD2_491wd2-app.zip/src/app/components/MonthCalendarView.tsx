import React from 'react';

interface MonthCalendarViewProps {
  currentDate: Date;
  appointments: any[];
}

export function MonthCalendarView({ currentDate, appointments }: MonthCalendarViewProps) {
  const getDaysInMonth = () => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();

    const days = [];
    
    // Add empty cells for days before the month starts
    for (let i = 0; i < startingDayOfWeek; i++) {
      days.push(null);
    }
    
    // Add all days in the month
    for (let i = 1; i <= daysInMonth; i++) {
      days.push(new Date(year, month, i));
    }
    
    return days;
  };

  const days = getDaysInMonth();
  const weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const monthName = currentDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

  return (
    <div className="bg-white rounded-3xl border border-gray-100 overflow-hidden">
      <div className="p-6 border-b border-gray-100">
        <h3 className="text-xl text-gray-900">{monthName}</h3>
      </div>

      {/* Week Days Header */}
      <div className="grid grid-cols-7 border-b border-gray-100">
        {weekDays.map((day) => (
          <div key={day} className="p-4 text-center text-sm text-gray-500 font-medium">
            {day}
          </div>
        ))}
      </div>

      {/* Calendar Grid */}
      <div className="grid grid-cols-7">
        {days.map((day, index) => {
          const isToday = day?.toDateString() === new Date().toDateString();
          const hasAppointments = day && [1, 5, 8, 15, 22].includes(day.getDate()); // Mock data
          
          return (
            <div
              key={index}
              className={`min-h-[120px] p-3 border-b border-r border-gray-100 hover:bg-gray-50 transition-colors cursor-pointer ${
                !day ? 'bg-gray-50' : ''
              }`}
            >
              {day && (
                <>
                  <div className={`text-right mb-2 ${
                    isToday 
                      ? 'w-8 h-8 ml-auto bg-[#8B5A7C] text-white rounded-full flex items-center justify-center text-sm'
                      : 'text-gray-900'
                  }`}>
                    {day.getDate()}
                  </div>
                  {hasAppointments && (
                    <div className="space-y-1">
                      <div className="bg-[#F5E6F1] rounded-lg px-2 py-1 text-xs text-[#8B5A7C]">
                        9:00 - Hair Cut
                      </div>
                      {day.getDate() % 2 === 0 && (
                        <div className="bg-[#E8F4F8] rounded-lg px-2 py-1 text-xs text-[#5A8B9E]">
                          2:00 - Color
                        </div>
                      )}
                    </div>
                  )}
                </>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
