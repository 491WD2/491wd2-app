# Disinfect outdoor bins

Type: Chores
Status: Not started
Room: 🗑️ Trash & Recycling (https://www.notion.so/Trash-Recycling-2ef97e9c2a3181249089f3915f94b75c?pvs=21)
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Disinfect outdoor trash and recycling bins monthly to prevent odors and pests.

---

### ✅ What I have to-do

---

- [ ]  Empty bins completely
- [ ]  Spray with disinfectant
- [ ]  Scrub with stiff brush
- [ ]  Rinse with hose and dry

### ❌ What I need to avoid

---

- Cleaning on trash day
- Skipping lids and handles
- Leaving standing water

---