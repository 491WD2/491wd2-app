# Clean windows and mirrors

Type: Chores
Status: Not started
Completion %: 0%
Frequency: Weekly

### ✏️ Cleaning Description

---

Clean windows and mirrors weekly for clear, streak-free views throughout the room.

---

### ✅ What I have to-do

---

- [ ]  Dust frames and sills
- [ ]  Spray glass cleaner
- [ ]  Wipe with microfiber cloth
- [ ]  Buff to shine

### ❌ What I need to avoid

---

- Cleaning in direct sun
- Leaving streaks
- Using paper towels

---