# Organize under sink

Type: Chores
Status: Not started
Room: 🚽 Half Bath (https://www.notion.so/Half-Bath-2ef97e9c2a3181d881c4f8476b0304b8?pvs=21)
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Organize under the bathroom sink monthly, removing clutter and expired products.

---

### ✅ What I have to-do

---

- [ ]  Remove all items
- [ ]  Wipe cabinet thoroughly
- [ ]  Check for leaks
- [ ]  Reorganize with bins or dividers

### ❌ What I need to avoid

---

- Keeping expired products
- Ignoring water damage
- Overcrowding the space

---