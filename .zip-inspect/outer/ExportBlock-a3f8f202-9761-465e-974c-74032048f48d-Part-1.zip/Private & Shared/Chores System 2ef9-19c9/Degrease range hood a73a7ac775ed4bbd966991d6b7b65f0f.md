# Degrease range hood

Type: Chores
Status: Not started
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Degrease the range hood monthly to remove built-up cooking oil and grime.

---

### ✅ What I have to-do

---

- [ ]  Remove and soak filters
- [ ]  Spray hood with degreaser
- [ ]  Scrub stubborn spots
- [ ]  Wipe clean and replace filters

### ❌ What I need to avoid

---

- Neglecting the filters
- Using abrasive scrubbers on finish
- Leaving grease buildup

---