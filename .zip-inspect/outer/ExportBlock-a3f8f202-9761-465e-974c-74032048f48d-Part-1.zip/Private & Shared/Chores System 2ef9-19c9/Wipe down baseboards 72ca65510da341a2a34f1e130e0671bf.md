# Wipe down baseboards

Type: Chores
Status: Not started
Room: 🛏️ Bedroom (https://www.notion.so/Bedroom-2ef97e9c2a318104bfe5c06efed42020?pvs=21)
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Wipe down bedroom baseboards monthly to remove dust and maintain cleanliness.

---

### ✅ What I have to-do

---

- [ ]  Dust baseboards first
- [ ]  Wipe with damp cloth
- [ ]  Remove scuff marks
- [ ]  Dry thoroughly

### ❌ What I need to avoid

---

- Excessive moisture
- Abrasive cleaners
- Missing behind furniture

---