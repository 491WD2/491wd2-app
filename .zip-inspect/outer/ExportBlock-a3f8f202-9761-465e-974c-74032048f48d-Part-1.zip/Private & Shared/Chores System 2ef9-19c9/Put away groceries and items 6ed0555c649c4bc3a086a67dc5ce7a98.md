# Put away groceries and items

Type: Chores
Status: Not started
Room: 🥫 Pantry (https://www.notion.so/Pantry-2ef97e9c2a3181979138c282576cd910?pvs=21)
Completion %: 0%
Frequency: Daily

### ✏️ Cleaning Description

---

Organize and store groceries and items properly in the pantry after shopping.

---

### ✅ What I have to-do

---

- [ ]  Sort items by category
- [ ]  Check expiration dates
- [ ]  Place items in designated spots
- [ ]  Rotate older items to front

### ❌ What I need to avoid

---

- Placing items randomly
- Blocking older items behind new ones
- Leaving bags on the floor

---