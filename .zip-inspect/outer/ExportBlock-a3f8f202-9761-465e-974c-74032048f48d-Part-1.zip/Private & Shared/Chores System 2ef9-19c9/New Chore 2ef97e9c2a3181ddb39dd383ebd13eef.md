# New Chore

Date: October 18, 2024
Type: Chores
Status: In progress
Completion %: 0%

### ✏️ Cleaning Description

---

<aside>
▪️

</aside>

---

### ✅ What I have to-do

---

- [ ]  Sub-task to-do…
- [ ]  Sub-task to-do…
- [ ]  Sub-task to-do…

### ❌ What I need to avoid

---

- Thing to avoid
- Thing to avoid
- Thing to avoid

---