# Organize recycling area

Type: Chores
Status: Not started
Room: 🗑️ Trash & Recycling (https://www.notion.so/Trash-Recycling-2ef97e9c2a3181249089f3915f94b75c?pvs=21)
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Organize recycling area monthly to maintain an efficient sorting system.

---

### ✅ What I have to-do

---

- [ ]  Empty all recycling bins
- [ ]  Wipe down bins and area
- [ ]  Reorganize by material type
- [ ]  Label bins clearly

### ❌ What I need to avoid

---

- Mixing recyclable types
- Leaving non-recyclables
- Cluttered sorting area

---