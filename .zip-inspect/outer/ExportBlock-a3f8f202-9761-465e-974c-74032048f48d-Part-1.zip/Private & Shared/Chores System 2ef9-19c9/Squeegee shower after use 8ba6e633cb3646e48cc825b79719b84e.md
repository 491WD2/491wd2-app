# Squeegee shower after use

Type: Chores
Status: Not started
Completion %: 0%
Frequency: Daily

### ✏️ Cleaning Description

---

Use a squeegee on shower walls and doors after each use to prevent water spots and mildew.

---

### ✅ What I have to-do

---

- [ ]  Squeegee all glass surfaces
- [ ]  Start from top and pull down
- [ ]  Wipe squeegee blade between passes
- [ ]  Get tile walls if needed

### ❌ What I need to avoid

---

- Leaving water on glass doors
- Using upward strokes
- Skipping corners and edges

---