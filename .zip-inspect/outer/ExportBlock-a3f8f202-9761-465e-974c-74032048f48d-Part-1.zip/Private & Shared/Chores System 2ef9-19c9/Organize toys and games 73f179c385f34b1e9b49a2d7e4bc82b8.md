# Organize toys and games

Type: Chores
Status: Not started
Room: 👨‍👩‍👧‍👦 Family Room (https://www.notion.so/Family-Room-2ef97e9c2a3181c7b087f2438a1f9bf9?pvs=21)
Completion %: 0%
Frequency: Weekly

### ✏️ Cleaning Description

---

Vacuum family room floor weekly to remove dirt, crumbs, and pet hair.

---

### ✅ What I have to-do

---

- [ ]  Clear floor of toys and items
- [ ]  Vacuum entire room
- [ ]  Move furniture if possible
- [ ]  Use attachments for edges

### ❌ What I need to avoid

---

- Vacuuming over large objects
- Missing under furniture
- Using full canister

---