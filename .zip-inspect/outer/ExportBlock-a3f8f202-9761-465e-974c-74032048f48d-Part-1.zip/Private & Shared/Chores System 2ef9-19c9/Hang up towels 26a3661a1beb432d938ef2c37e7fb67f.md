# Hang up towels

Type: Chores
Status: Not started
Completion %: 0%
Frequency: Daily

### ✏️ Cleaning Description

Hang bathroom towels properly on racks to allow proper drying, maintain a tidy appearance, and prevent mildew growth.

---

### 📋 Step-by-Step Instructions

- [ ]  Check all towels currently on racks
- [ ]  Straighten any crooked or bunched towels
- [ ]  Spread towels out fully for proper air circulation
- [ ]  Pick up any towels from the floor
- [ ]  Shake out floor towels before rehanging
- [ ]  Hang towels evenly spaced on bars
- [ ]  Ensure each towel can dry properly
- [ ]  Replace very damp towels with dry ones

### ⚠️ Important Safety & Mistakes to Avoid

- Don't bunch towels preventing proper drying
- Never leave towels on the floor
- Avoid overloading towel bars with too many towels
- Don't hang wet towels in poorly ventilated areas
- Never ignore musty smelling towels that need washing

---