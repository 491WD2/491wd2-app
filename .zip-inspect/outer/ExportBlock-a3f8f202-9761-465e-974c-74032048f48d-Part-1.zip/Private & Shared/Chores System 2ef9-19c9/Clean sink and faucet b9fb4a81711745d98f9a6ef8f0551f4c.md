# Clean sink and faucet

Type: Chores
Status: Not started
Completion %: 0%
Frequency: Daily

### ✏️ Cleaning Description

Clean and sanitize the kitchen sink and faucet, removing food residue, water spots, and buildup to maintain a hygienic cooking environment.

---

### 📋 Step-by-Step Instructions

- [ ]  Clear the sink of all dishes, utensils, and debris
- [ ]  Rinse the entire sink with hot water to loosen grime
- [ ]  Apply sink cleaner or baking soda paste to basin
- [ ]  Scrub sink basin thoroughly with sponge or brush
- [ ]  Pay special attention to corners and drain area
- [ ]  Clean faucet, handles, and base with same cleaner
- [ ]  Rinse everything thoroughly with hot water
- [ ]  Dry completely with clean microfiber cloth
- [ ]  Polish faucet for shine if desired

### ⚠️ Important Safety & Mistakes to Avoid

- Never use abrasive cleaners or steel wool on stainless steel
- Don't leave standing water in sink after cleaning
- Never mix bleach with other cleaning chemicals
- Avoid using harsh acids on delicate sink finishes
- Don't forget to clean the faucet aerator periodically

---