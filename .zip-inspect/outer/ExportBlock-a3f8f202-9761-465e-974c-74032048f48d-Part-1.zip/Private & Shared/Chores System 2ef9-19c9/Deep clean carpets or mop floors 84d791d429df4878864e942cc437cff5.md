# Deep clean carpets or mop floors

Type: Chores
Status: Not started
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Deep clean carpets or thoroughly mop floors monthly for a fresh, clean room.

---

### ✅ What I have to-do

---

- [ ]  Vacuum thoroughly first
- [ ]  Use carpet cleaner or mop
- [ ]  Treat stains as needed
- [ ]  Allow to dry completely

### ❌ What I need to avoid

---

- Over-wetting carpets
- Walking on wet floors
- Skipping pre-vacuum

---