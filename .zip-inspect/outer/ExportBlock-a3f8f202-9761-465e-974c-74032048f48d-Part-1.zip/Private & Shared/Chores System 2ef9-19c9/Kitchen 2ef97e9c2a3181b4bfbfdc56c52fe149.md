# Kitchen

Date: January 26, 2026
Type: Chores
Status: Not started
Assigned: Elijah & Roskens 
Completion %: 0%
Frequency: Weekly

### ✏️ Cleaning Description

---

Wipe down countertops

Clean sink and faucet

Wash dishes or load dishwasher

Sweep floor

Wipe down stovetop

Take out trash

---

### ✅ What I have to-do

---

- [ ]  Wipe down countertops
- [ ]  Clean sink and faucet
- [ ]  Wash dishes or load dishwasher
- [ ]  Sweep floor
- [ ]  Wipe down stovetop
- [ ]  Take out trash

### ❌ What I need to avoid

---

- Thing to avoid
- Thing to avoid
- Thing to avoid

---