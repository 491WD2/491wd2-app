# Wipe down walls and doors

Type: Chores
Status: Not started
Room: 👨‍👩‍👧‍👦 Family Room (https://www.notion.so/Family-Room-2ef97e9c2a3181c7b087f2438a1f9bf9?pvs=21)
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Wipe down family room walls and doors monthly to remove dust and handprints.

---

### ✅ What I have to-do

---

- [ ]  Dust all wall surfaces
- [ ]  Wipe walls with cleaner
- [ ]  Clean doors front and back
- [ ]  Remove marks and spots

### ❌ What I need to avoid

---

- Using too much moisture
- Harsh chemicals on paint
- Missing high-touch areas

---