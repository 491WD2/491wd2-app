# Take out kitchen trash

Type: Chores
Status: Not started
Room: 🗑️ Trash & Recycling (https://www.notion.so/Trash-Recycling-2ef97e9c2a3181249089f3915f94b75c?pvs=21)
Completion %: 0%
Frequency: Daily

### ✏️ Cleaning Description

---

Take out kitchen trash daily to prevent odors and maintain kitchen hygiene.

---

### ✅ What I have to-do

---

- [ ]  Remove full trash bag
- [ ]  Tie bag securely to prevent leaks
- [ ]  Take to outdoor trash bin
- [ ]  Replace with fresh liner

### ❌ What I need to avoid

---

- Overfilling bag causing tears
- Leaving trash can without liner
- Ignoring spills in can bottom

---