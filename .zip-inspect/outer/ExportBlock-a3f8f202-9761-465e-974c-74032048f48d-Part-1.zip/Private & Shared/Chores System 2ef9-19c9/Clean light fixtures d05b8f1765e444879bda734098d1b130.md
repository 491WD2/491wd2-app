# Clean light fixtures

Type: Chores
Status: Not started
Room: 🚶 Halls (https://www.notion.so/Halls-2ef97e9c2a31812b92fed8399ea05356?pvs=21)
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Clean hallway light fixtures monthly to remove dust and maintain brightness.

---

### ✅ What I have to-do

---

- [ ]  Turn off lights and cool
- [ ]  Remove covers carefully
- [ ]  Dust and wipe fixtures
- [ ]  Reinstall covers

### ❌ What I need to avoid

---

- Working with power on
- Getting water in sockets
- Breaking delicate covers

---