# Vacuum high-traffic areas

Type: Chores
Status: Not started
Room: 👨‍👩‍👧‍👦 Family Room (https://www.notion.so/Family-Room-2ef97e9c2a3181c7b087f2438a1f9bf9?pvs=21)
Completion %: 0%
Frequency: Daily

### ✏️ Cleaning Description

---

Vacuum high-traffic areas in the family room to remove dirt, crumbs, and debris.

---

### ✅ What I have to-do

---

- [ ]  Pick up large items from floor
- [ ]  Vacuum main traffic paths
- [ ]  Get around and under furniture
- [ ]  Use attachments for edges

### ❌ What I need to avoid

---

- Vacuuming over large objects
- Missing under furniture edges
- Using with full canister

---