# Clean door and frame

Type: Chores
Status: Not started
Room: 🚪 Entry (https://www.notion.so/Entry-2ef97e9c2a3181f78171fb35aa12d167?pvs=21)
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Clean the entryway door and frame, removing fingerprints, dirt, and scuffs.

---

### ✅ What I have to-do

---

- [ ]  Wipe door front and back
- [ ]  Clean door handle thoroughly
- [ ]  Wipe door frame and edges
- [ ]  Clean glass if applicable

### ❌ What I need to avoid

---

- Using abrasives on finish
- Missing high-touch areas
- Leaving streaks on glass

---