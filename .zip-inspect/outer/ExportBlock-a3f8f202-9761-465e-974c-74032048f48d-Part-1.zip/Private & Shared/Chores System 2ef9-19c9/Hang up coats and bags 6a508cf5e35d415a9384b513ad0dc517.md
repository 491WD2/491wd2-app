# Hang up coats and bags

Type: Chores
Status: Not started
Room: 🚪 Entry (https://www.notion.so/Entry-2ef97e9c2a3181f78171fb35aa12d167?pvs=21)
Completion %: 0%
Frequency: Daily

### ✏️ Cleaning Description

Hang coats and bags on designated hooks or in closet to prevent entryway clutter and maintain an organized, welcoming entrance.

---

### 📋 Step-by-Step Instructions

- [ ]  Pick up all coats and jackets from floor or furniture
- [ ]  Shake out each coat to remove debris
- [ ]  Hang coats on designated hooks or hangers
- [ ]  Distribute weight evenly on hooks
- [ ]  Gather all bags and backpacks
- [ ]  Hang bags on designated hooks
- [ ]  Clear floor and bench space completely
- [ ]  Arrange items neatly for easy access

### ⚠️ Important Safety & Mistakes to Avoid

- Don't drape coats over furniture or chairs
- Never leave bags on the floor creating trip hazards
- Avoid overloading hooks causing them to fail
- Don't mix wet and dry coats on same hook
- Never leave outdoor items blocking the entryway

---