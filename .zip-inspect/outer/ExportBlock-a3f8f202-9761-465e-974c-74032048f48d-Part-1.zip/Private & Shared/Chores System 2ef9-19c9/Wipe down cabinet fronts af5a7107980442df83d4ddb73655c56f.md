# Wipe down cabinet fronts

Type: Chores
Status: Not started
Completion %: 0%
Frequency: Weekly

### ✏️ Cleaning Description

---

Clean the kitchen cabinet fronts, removing fingerprints, grease, and dust buildup.

---

### ✅ What I have to-do

---

- [ ]  Dust cabinet surfaces
- [ ]  Wipe all cabinet doors
- [ ]  Clean cabinet handles
- [ ]  Dry with clean cloth

### ❌ What I need to avoid

---

- Using too much water on wood
- Harsh chemicals on finishes
- Forgetting handles and edges

---