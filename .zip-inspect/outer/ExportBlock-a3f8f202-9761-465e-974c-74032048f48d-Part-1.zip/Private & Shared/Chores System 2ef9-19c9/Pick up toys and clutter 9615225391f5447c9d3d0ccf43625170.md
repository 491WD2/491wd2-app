# Pick up toys and clutter

Type: Chores
Status: Not started
Room: 👨‍👩‍👧‍👦 Family Room (https://www.notion.so/Family-Room-2ef97e9c2a3181c7b087f2438a1f9bf9?pvs=21)
Completion %: 0%
Frequency: Daily

### ✏️ Cleaning Description

---

Pick up toys and clutter to maintain a safe and organized family room.

---

### ✅ What I have to-do

---

- [ ]  Gather all toys from floor
- [ ]  Sort toys by type or container
- [ ]  Return to toy storage
- [ ]  Clear other clutter

### ❌ What I need to avoid

---

- Leaving small toys that are tripping hazards
- Tossing toys without sorting
- Ignoring broken or missing pieces

---