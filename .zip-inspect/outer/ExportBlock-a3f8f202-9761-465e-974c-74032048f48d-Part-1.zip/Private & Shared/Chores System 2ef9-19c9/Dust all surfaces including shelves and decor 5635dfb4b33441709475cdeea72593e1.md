# Dust all surfaces including shelves and decor

Type: Chores
Status: Not started
Completion %: 0%
Frequency: Weekly

### ✏️ Cleaning Description

---

Dust all surfaces weekly including furniture, shelves, and decorative items.

---

### ✅ What I have to-do

---

- [ ]  Start from highest surfaces
- [ ]  Use microfiber cloth
- [ ]  Dust all furniture
- [ ]  Clean decorative items

### ❌ What I need to avoid

---

- Just moving dust around
- Missing tops of frames
- Skipping hard-to-reach spots

---