import React, { useState } from 'react';
import { X, Calendar, Clock, User } from 'lucide-react';

interface EditAppointmentModalProps {
  appointment: any;
  onClose: () => void;
  onSave: (updated: any) => void;
}

export function EditAppointmentModal({ appointment, onClose, onSave }: EditAppointmentModalProps) {
  const [formData, setFormData] = useState({
    client: appointment.client,
    service: appointment.service,
    stylist: appointment.stylist,
    time: appointment.time,
    duration: appointment.duration,
    date: new Date().toISOString().split('T')[0],
  });

  const stylists = ['Jenny', 'Min', 'Soo', 'Grace'];
  const services = [
    'Hair Cut & Style',
    'Color Treatment',
    'Hair Perm',
    'Treatment & Styling',
    'Highlights',
    'Balayage',
  ];

  const handleSave = () => {
    onSave({ ...appointment, ...formData });
  };

  return (
    <div className="fixed inset-0 bg-black/20 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-8 border-b border-gray-100">
          <div>
            <h2 className="text-2xl text-gray-900">Edit Appointment</h2>
            <p className="text-gray-400 mt-1">Update appointment details</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-50 rounded-xl transition-colors"
          >
            <X className="w-6 h-6 text-gray-400" />
          </button>
        </div>

        <div className="p-8 space-y-6">
          <div>
            <label className="block text-sm text-gray-600 mb-3">
              <User className="w-4 h-4 inline mr-2" />
              Client Name
            </label>
            <input
              type="text"
              value={formData.client}
              onChange={(e) => setFormData({ ...formData, client: e.target.value })}
              className="w-full px-5 py-4 rounded-2xl border border-gray-200 focus:outline-none focus:border-[#8B5A7C] transition-colors"
            />
          </div>

          <div>
            <label className="block text-sm text-gray-600 mb-3">Service</label>
            <select
              value={formData.service}
              onChange={(e) => setFormData({ ...formData, service: e.target.value })}
              className="w-full px-5 py-4 rounded-2xl border border-gray-200 focus:outline-none focus:border-[#8B5A7C] transition-colors"
            >
              {services.map((service) => (
                <option key={service} value={service}>
                  {service}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm text-gray-600 mb-3">Stylist</label>
            <select
              value={formData.stylist}
              onChange={(e) => setFormData({ ...formData, stylist: e.target.value })}
              className="w-full px-5 py-4 rounded-2xl border border-gray-200 focus:outline-none focus:border-[#8B5A7C] transition-colors"
            >
              {stylists.map((stylist) => (
                <option key={stylist} value={stylist}>
                  {stylist}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm text-gray-600 mb-3">
                <Calendar className="w-4 h-4 inline mr-2" />
                Date
              </label>
              <input
                type="date"
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                className="w-full px-5 py-4 rounded-2xl border border-gray-200 focus:outline-none focus:border-[#8B5A7C] transition-colors"
              />
            </div>
            <div>
              <label className="block text-sm text-gray-600 mb-3">
                <Clock className="w-4 h-4 inline mr-2" />
                Time
              </label>
              <input
                type="time"
                value={formData.time}
                onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                className="w-full px-5 py-4 rounded-2xl border border-gray-200 focus:outline-none focus:border-[#8B5A7C] transition-colors"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm text-gray-600 mb-3">Duration</label>
            <select
              value={formData.duration}
              onChange={(e) => setFormData({ ...formData, duration: e.target.value })}
              className="w-full px-5 py-4 rounded-2xl border border-gray-200 focus:outline-none focus:border-[#8B5A7C] transition-colors"
            >
              <option value="30 min">30 minutes</option>
              <option value="45 min">45 minutes</option>
              <option value="60 min">60 minutes</option>
              <option value="75 min">75 minutes</option>
              <option value="90 min">90 minutes</option>
              <option value="120 min">120 minutes</option>
            </select>
          </div>
        </div>

        <div className="p-8 border-t border-gray-100 flex gap-3">
          <button
            onClick={onClose}
            className="flex-1 py-4 bg-gray-100 text-gray-600 rounded-2xl hover:bg-gray-200 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            className="flex-1 py-4 bg-[#8B5A7C] text-white rounded-2xl hover:bg-[#7A4F6C] transition-colors"
          >
            Save Changes
          </button>
        </div>
      </div>
    </div>
  );
}
