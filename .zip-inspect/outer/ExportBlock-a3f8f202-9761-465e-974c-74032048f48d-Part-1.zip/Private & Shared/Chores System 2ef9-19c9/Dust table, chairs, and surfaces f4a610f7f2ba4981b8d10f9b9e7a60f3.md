# Dust table, chairs, and surfaces

Type: Chores
Status: Not started
Room: 🍽️ Dining Room (https://www.notion.so/Dining-Room-2ef97e9c2a318192bdd0f0418b269200?pvs=21)
Completion %: 0%
Frequency: Weekly

### ✏️ Cleaning Description

---

Dust dining room furniture weekly including table, chairs, and buffet.

---

### ✅ What I have to-do

---

- [ ]  Dust table and chairs
- [ ]  Clean buffet or sideboard
- [ ]  Dust chair legs and rungs
- [ ]  Get decorative items

### ❌ What I need to avoid

---

- Missing chair backs
- Leaving dust on decor
- Skipping under table edges

---