# Wipe down coffee table and side tables

Type: Chores
Status: Not started
Completion %: 0%
Frequency: Daily

### ✏️ Cleaning Description

---

Wipe down coffee table and side tables to remove dust, crumbs, and spills.

---

### ✅ What I have to-do

---

- [ ]  Remove items from surfaces
- [ ]  Wipe with appropriate cleaner
- [ ]  Clean table legs and edges
- [ ]  Return items neatly

### ❌ What I need to avoid

---

- Using too much liquid on wood
- Leaving water rings
- Scratching with abrasive cloths

---