# Dust TV screen and electronics

Type: Chores
Status: Not started
Completion %: 0%
Frequency: Weekly

### ✏️ Cleaning Description

---

Dust surfaces and shelves weekly to remove buildup and maintain cleanliness.

---

### ✅ What I have to-do

---

- [ ]  Dust from top to bottom
- [ ]  Clean all shelves
- [ ]  Dust decorative items
- [ ]  Use microfiber cloth

### ❌ What I need to avoid

---

- Just moving dust around
- Missing high shelves
- Using feather dusters that spread dust

---