# Vacuum floor

Type: Chores
Status: Not started
Room: 🛏️ Bedroom (https://www.notion.so/Bedroom-2ef97e9c2a318104bfe5c06efed42020?pvs=21)
Completion %: 0%
Frequency: Weekly

### ✏️ Cleaning Description

---

Wash kitchen towels weekly to maintain hygiene and prevent odors.

---

### ✅ What I have to-do

---

- [ ]  Gather all kitchen towels
- [ ]  Wash in hot water
- [ ]  Dry completely
- [ ]  Replace with fresh towels

### ❌ What I need to avoid

---

- Using damp towels
- Washing with other laundry
- Letting mildew develop

---