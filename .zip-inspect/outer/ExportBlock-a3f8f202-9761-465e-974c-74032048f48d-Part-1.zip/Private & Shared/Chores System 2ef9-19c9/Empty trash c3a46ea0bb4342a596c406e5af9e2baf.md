# Empty trash

Type: Chores
Status: Not started
Room: 🚽 Half Bath (https://www.notion.so/Half-Bath-2ef97e9c2a3181d881c4f8476b0304b8?pvs=21)
Completion %: 0%
Frequency: Daily

### ✏️ Cleaning Description

Remove and dispose of bathroom trash daily to maintain hygiene, prevent odors, and keep the bathroom fresh and clean.

---

### 📋 Step-by-Step Instructions

- [ ]  Check if trash bag is full or contains odorous items
- [ ]  Remove trash bag from bin carefully
- [ ]  Tie bag securely to prevent leaks or spills
- [ ]  Take bag to outdoor trash collection area
- [ ]  Wipe inside of trash can if needed
- [ ]  Replace with fresh liner appropriate size
- [ ]  Ensure liner is properly positioned
- [ ]  Check that bin is clean and dry

### ⚠️ Important Safety & Mistakes to Avoid

- Don't overfill the trash bin causing spills
- Never leave trash can without a liner
- Avoid forgetting to check for leaks in the bin bottom
- Don't let trash sit multiple days if it contains hygiene products
- Never place sharp items loosely in bathroom trash

---