# Wipe down sink and counter

Type: Chores
Status: Not started
Room: 🚽 Half Bath (https://www.notion.so/Half-Bath-2ef97e9c2a3181d881c4f8476b0304b8?pvs=21)
Completion %: 0%
Frequency: Daily

### ✏️ Cleaning Description

---

Wipe down bathroom sink and counter to remove toothpaste, water spots, and debris.

---

### ✅ What I have to-do

---

- [ ]  Clear counter of items
- [ ]  Wipe sink basin and faucet
- [ ]  Clean entire counter surface
- [ ]  Dry and buff fixtures

### ❌ What I need to avoid

---

- Leaving toothpaste residue
- Missing faucet base
- Using abrasive cleaners

---