# Clean light fixtures

Type: Chores
Status: Not started
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Clean kitchen light fixtures monthly to remove grease, dust, and improve brightness.

---

### ✅ What I have to-do

---

- [ ]  Turn off and let cool completely
- [ ]  Remove covers or shades
- [ ]  Wash with soapy water
- [ ]  Dry and reassemble

### ❌ What I need to avoid

---

- Cleaning while hot or on
- Submerging electrical parts
- Using abrasive cleaners

---