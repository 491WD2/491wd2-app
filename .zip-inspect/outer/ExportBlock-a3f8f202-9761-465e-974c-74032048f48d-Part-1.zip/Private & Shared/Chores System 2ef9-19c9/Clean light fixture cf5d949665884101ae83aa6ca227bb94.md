# Clean light fixture

Type: Chores
Status: Not started
Room: 🚽 Half Bath (https://www.notion.so/Half-Bath-2ef97e9c2a3181d881c4f8476b0304b8?pvs=21)
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Clean bathroom light fixture monthly to remove dust and improve lighting.

---

### ✅ What I have to-do

---

- [ ]  Turn off light and let cool
- [ ]  Remove fixture cover
- [ ]  Dust and wipe clean
- [ ]  Replace cover securely

### ❌ What I need to avoid

---

- Cleaning while hot
- Using excessive water
- Forcing stuck parts

---