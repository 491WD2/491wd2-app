# Wipe down walls and baseboards

Type: Chores
Status: Not started
Room: 🍽️ Dining Room (https://www.notion.so/Dining-Room-2ef97e9c2a318192bdd0f0418b269200?pvs=21)
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Wipe down dining room walls and baseboards monthly to remove dust and marks.

---

### ✅ What I have to-do

---

- [ ]  Dust walls from top down
- [ ]  Wipe walls with cleaner
- [ ]  Clean baseboards thoroughly
- [ ]  Dry all surfaces

### ❌ What I need to avoid

---

- Using excessive water
- Harsh cleaners on paint
- Missing corners and edges

---