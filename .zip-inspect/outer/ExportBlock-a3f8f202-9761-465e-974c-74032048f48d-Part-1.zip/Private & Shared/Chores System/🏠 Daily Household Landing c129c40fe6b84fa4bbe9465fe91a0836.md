# 🏠 Daily Household Landing

<aside>
✅

**Today (start here)**

Open the TODAY view and do the next right thing.

</aside>

### ✅ TODAY

[Open TODAY](view://2ef97e9c-2a31-8128-b9be-000ccf9a9196)

### 🧭 Quick Actions

- If TODAY is empty, check **UNSCHEDULED** for chores missing a Date.
- If something vanished, check **ARCHIVE** or view filters.

---

### 📅 This Week

[Open WEEKLY](view://2ef97e9c-2a31-81d1-af6b-000c49a7b2fc)

### 🗓 Calendar (planning)

[Open CALENDAR](view://2ef97e9c-2a31-81b7-bfba-000cad0a4109)

---

### 🔄 5-Minute Weekly Reset (gentle, not a rebuild)

Do this once a week (suggestion: Sunday evening or Monday morning).

1. Open **WEEKLY**.
2. Scan for anything overdue or unrealistic.
3. For any chore you still want to happen this week, set a **Date** on a specific day.
4. If something is not happening this week, either:
    - Move the **Date** to next week, or
    - Clear the Date so it lives in **UNSCHEDULED** until planned.
5. Do a quick pass on **Assigned To** so each person has a reasonable load.

---

### 🍳🛁 Rotation Mapping (kitchen + bathroom) — manual, clean, predictable

Use this simple pattern:

- Keep chores as **Type = Chores**.
- Treat **Date** as the **next due day**.
- Manage rotations by updating **Assigned To** (not by duplicating chores).

**Rotation steps (weekly):**

1. In WEEKLY, filter (temporarily) to Room = Kitchen or Bathroom.
2. Re-assign the rotation chores to the next person.
3. Make sure each of those chores has a Date inside the coming week.

**Rule of thumb:** one primary “anchor” chore per person per day, plus intentional exceptions (trash, quick wipes).