import React, { useState } from 'react';
import { X, Check, CreditCard, Banknote, Ticket, Mail, Printer } from 'lucide-react';

interface CheckoutModalProps {
  appointment?: any;
  onClose: () => void;
}

export function CheckoutModal({ appointment, onClose }: CheckoutModalProps) {
  const [servicePrice, setServicePrice] = useState('');
  const [weekendSurcharge, setWeekendSurcharge] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'card' | 'voucher' | 'partial'>('card');
  const [partialAmount, setPartialAmount] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isComplete, setIsComplete] = useState(false);
  const [showReceiptOptions, setShowReceiptOptions] = useState(false);

  const GST_RATE = 0.1; // 10%
  const WEEKEND_SURCHARGE_RATE = 0.15; // 15%

  const calculateTotals = () => {
    const base = parseFloat(servicePrice) || 0;
    const surcharge = weekendSurcharge ? base * WEEKEND_SURCHARGE_RATE : 0;
    const subtotal = base + surcharge;
    const gst = subtotal * GST_RATE;
    const total = subtotal + gst;

    return {
      base,
      surcharge,
      subtotal,
      gst,
      total,
    };
  };

  const totals = calculateTotals();

  const handleCheckout = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      setShowReceiptOptions(true);
    }, 1000);
  };

  const handleReceiptOption = (option: 'email' | 'print' | 'skip') => {
    if (option === 'email') {
      alert('Receipt sent to client email');
    } else if (option === 'print') {
      alert('Receipt printing...');
    }
    setIsComplete(true);
    setTimeout(() => {
      onClose();
    }, 1500);
  };

  const isWeekend = () => {
    const day = new Date().getDay();
    return day === 0 || day === 6;
  };

  const paymentMethods = [
    { id: 'card' as const, label: 'Card', icon: CreditCard },
    { id: 'cash' as const, label: 'Cash', icon: Banknote },
    { id: 'voucher' as const, label: 'Voucher', icon: Ticket },
    { id: 'partial' as const, label: 'Partial', icon: CreditCard },
  ];

  return (
    <div className="fixed inset-0 bg-black/20 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl shadow-2xl max-w-xl w-full max-h-[90vh] overflow-y-auto">
        {isComplete ? (
          <div className="p-12 text-center">
            <div className="w-20 h-20 rounded-full bg-[#F0F4E8] flex items-center justify-center mx-auto mb-6">
              <Check className="w-10 h-10 text-[#6B8B5A]" />
            </div>
            <h2 className="text-2xl text-gray-900 mb-2">Payment Complete</h2>
            <p className="text-gray-500">Thank you for your visit!</p>
          </div>
        ) : showReceiptOptions ? (
          <div className="p-8">
            <div className="text-center mb-8">
              <div className="w-20 h-20 rounded-full bg-[#F0F4E8] flex items-center justify-center mx-auto mb-6">
                <Check className="w-10 h-10 text-[#6B8B5A]" />
              </div>
              <h2 className="text-2xl text-gray-900 mb-2">Payment Successful</h2>
              <p className="text-gray-500">Would you like to send a receipt?</p>
            </div>
            <div className="space-y-3">
              <button
                onClick={() => handleReceiptOption('email')}
                className="w-full flex items-center justify-center gap-3 px-6 py-4 bg-[#8B5A7C] text-white rounded-2xl hover:bg-[#7A4F6C] transition-colors"
              >
                <Mail className="w-5 h-5" />
                <span>Email Receipt</span>
              </button>
              <button
                onClick={() => handleReceiptOption('print')}
                className="w-full flex items-center justify-center gap-3 px-6 py-4 bg-[#F5E6F1] text-[#8B5A7C] rounded-2xl hover:bg-[#EDD9E8] transition-colors"
              >
                <Printer className="w-5 h-5" />
                <span>Print Receipt</span>
              </button>
              <button
                onClick={() => handleReceiptOption('skip')}
                className="w-full px-6 py-4 text-gray-500 rounded-2xl hover:bg-gray-50 transition-colors"
              >
                Skip
              </button>
            </div>
          </div>
        ) : (
          <>
            <div className="flex items-center justify-between p-8 border-b border-gray-100">
              <div>
                <h2 className="text-2xl text-gray-900">Quick Checkout</h2>
                {appointment ? (
                  <p className="text-gray-400 mt-1">{appointment.client}</p>
                ) : (
                  <p className="text-gray-400 mt-1">Walk-In Customer</p>
                )}
              </div>
              <button
                onClick={onClose}
                className="p-2 hover:bg-gray-50 rounded-xl transition-colors"
              >
                <X className="w-6 h-6 text-gray-400" />
              </button>
            </div>

            <div className="p-8 space-y-6">
              {appointment && (
                <div className="bg-[#F5E6F1] rounded-2xl p-6">
                  <p className="text-sm text-gray-500 mb-1">Service</p>
                  <p className="text-lg text-gray-900">{appointment.service}</p>
                  <p className="text-sm text-gray-500 mt-2">
                    Duration: {appointment.duration}
                  </p>
                </div>
              )}

              <div>
                <label className="block text-sm text-gray-600 mb-3">
                  Service Price
                </label>
                <div className="relative">
                  <span className="absolute left-5 top-1/2 -translate-y-1/2 text-gray-400 text-lg">
                    $
                  </span>
                  <input
                    type="number"
                    value={servicePrice}
                    onChange={(e) => setServicePrice(e.target.value)}
                    placeholder="0.00"
                    step="0.01"
                    className="w-full pl-10 pr-5 py-4 rounded-2xl border border-gray-200 focus:outline-none focus:border-[#8B5A7C] transition-colors text-lg"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between p-5 bg-gray-50 rounded-2xl">
                <div>
                  <p className="text-gray-900 mb-1">Weekend Surcharge</p>
                  <p className="text-sm text-gray-500">
                    +15% on weekends
                    {isWeekend() && (
                      <span className="ml-2 px-2 py-0.5 bg-[#E8F4F8] text-[#5A8B9E] rounded-lg text-xs">
                        Today is weekend
                      </span>
                    )}
                  </p>
                </div>
                <button
                  onClick={() => setWeekendSurcharge(!weekendSurcharge)}
                  className={`relative w-14 h-8 rounded-full transition-colors ${
                    weekendSurcharge ? 'bg-[#8B5A7C]' : 'bg-gray-300'
                  }`}
                >
                  <span
                    className={`absolute top-1 w-6 h-6 bg-white rounded-full transition-transform ${
                      weekendSurcharge ? 'translate-x-7' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>

              <div>
                <label className="block text-sm text-gray-600 mb-3">
                  Payment Method
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {paymentMethods.map((method) => {
                    const Icon = method.icon;
                    return (
                      <button
                        key={method.id}
                        onClick={() => setPaymentMethod(method.id)}
                        className={`flex flex-col items-center gap-2 p-4 rounded-2xl border-2 transition-all ${
                          paymentMethod === method.id
                            ? 'border-[#8B5A7C] bg-[#F5E6F1]'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <Icon className={`w-6 h-6 ${
                          paymentMethod === method.id ? 'text-[#8B5A7C]' : 'text-gray-400'
                        }`} />
                        <span className={`text-xs ${
                          paymentMethod === method.id ? 'text-[#8B5A7C]' : 'text-gray-600'
                        }`}>
                          {method.label}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {paymentMethod === 'partial' && (
                <div>
                  <label className="block text-sm text-gray-600 mb-3">
                    Partial Payment Amount
                  </label>
                  <div className="relative">
                    <span className="absolute left-5 top-1/2 -translate-y-1/2 text-gray-400 text-lg">
                      $
                    </span>
                    <input
                      type="number"
                      value={partialAmount}
                      onChange={(e) => setPartialAmount(e.target.value)}
                      placeholder="0.00"
                      step="0.01"
                      className="w-full pl-10 pr-5 py-4 rounded-2xl border border-gray-200 focus:outline-none focus:border-[#8B5A7C] transition-colors text-lg"
                    />
                  </div>
                  {partialAmount && parseFloat(partialAmount) < totals.total && (
                    <p className="text-sm text-gray-500 mt-2">
                      Remaining: ${(totals.total - parseFloat(partialAmount)).toFixed(2)}
                    </p>
                  )}
                </div>
              )}

              <div className="space-y-3 pt-4">
                <div className="flex justify-between text-gray-600">
                  <span>Service Price</span>
                  <span>${totals.base.toFixed(2)}</span>
                </div>
                {weekendSurcharge && totals.surcharge > 0 && (
                  <div className="flex justify-between text-gray-600">
                    <span>Weekend Surcharge (15%)</span>
                    <span>${totals.surcharge.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between text-gray-600">
                  <span>Subtotal</span>
                  <span>${totals.subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-gray-600">
                  <span>GST (10%)</span>
                  <span>${totals.gst.toFixed(2)}</span>
                </div>
                <div className="h-px bg-gray-200" />
                <div className="flex justify-between text-xl text-gray-900">
                  <span>Total</span>
                  <span>${totals.total.toFixed(2)}</span>
                </div>
                {paymentMethod === 'partial' && partialAmount && (
                  <>
                    <div className="flex justify-between text-gray-600">
                      <span>Paying Now</span>
                      <span>${parseFloat(partialAmount).toFixed(2)}</span>
                    </div>
                  </>
                )}
              </div>
            </div>

            <div className="p-8 border-t border-gray-100">
              <button
                onClick={handleCheckout}
                disabled={!servicePrice || parseFloat(servicePrice) <= 0 || isProcessing}
                className="w-full py-4 bg-[#8B5A7C] text-white rounded-2xl hover:bg-[#7A4F6C] transition-colors disabled:opacity-50 disabled:cursor-not-allowed text-lg"
              >
                {isProcessing ? 'Processing...' : 'Complete Payment'}
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
