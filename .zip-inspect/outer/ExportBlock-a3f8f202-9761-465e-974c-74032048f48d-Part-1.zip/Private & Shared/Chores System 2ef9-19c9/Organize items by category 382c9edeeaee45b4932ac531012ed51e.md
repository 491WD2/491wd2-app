# Organize items by category

Type: Chores
Status: Not started
Room: 🥫 Pantry (https://www.notion.so/Pantry-2ef97e9c2a3181979138c282576cd910?pvs=21)
Completion %: 0%
Frequency: Weekly

### ✏️ Cleaning Description

---

Vacuum pantry floor weekly to remove crumbs, dust, and debris.

---

### ✅ What I have to-do

---

- [ ]  Remove items from floor
- [ ]  Vacuum entire floor
- [ ]  Get corners and edges
- [ ]  Check under bottom shelves

### ❌ What I need to avoid

---

- Missing corners
- Leaving crumbs
- Vacuuming over large spills

---