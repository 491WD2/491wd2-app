# Monthly Chore

Date: January 21, 2026
Type: Chores
Status: Not started
Room: 🛁  Bathroom (https://www.notion.so/Bathroom-2ef97e9c2a3181eb8860fe936b7b084a?pvs=21)
Completion %: 0%

### ✏️ Cleaning Description

---

<aside>
▪️

</aside>

---

### ✅ What I have to-do

---

- [ ]  Sub-task to-do…
- [ ]  Sub-task to-do…
- [ ]  Sub-task to-do…

### ❌ What I need to avoid

---

- Thing to avoid
- Thing to avoid
- Thing to avoid

---