# Deep clean all trash cans

Type: Chores
Status: Not started
Room: 🗑️ Trash & Recycling (https://www.notion.so/Trash-Recycling-2ef97e9c2a3181249089f3915f94b75c?pvs=21)
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Deep clean all trash cans monthly to remove odors, stains, and bacteria.

---

### ✅ What I have to-do

---

- [ ]  Empty all trash cans
- [ ]  Spray with disinfectant
- [ ]  Scrub inside and outside
- [ ]  Rinse and dry completely

### ❌ What I need to avoid

---

- Skipping the outsides
- Returning liners to wet cans
- Using harsh chemicals that damage

---