# Wipe down appliances

Type: Chores
Status: Not started
Completion %: 0%
Frequency: Weekly

### ✏️ Cleaning Description

---

Clean all kitchen appliances, removing fingerprints, spills, and dust from surfaces.

---

### ✅ What I have to-do

---

- [ ]  Wipe down refrigerator exterior
- [ ]  Clean dishwasher front
- [ ]  Wipe small appliances
- [ ]  Polish stainless steel

### ❌ What I need to avoid

---

- Using wrong cleaner for stainless steel
- Getting water in electrical areas
- Wiping against the grain

---