# Organize closet

Type: Chores
Status: Not started
Room: 🛏️ Bedroom (https://www.notion.so/Bedroom-2ef97e9c2a318104bfe5c06efed42020?pvs=21)
Completion %: 0%
Frequency: Weekly

### ✏️ Cleaning Description

---

Vacuum bedroom floor weekly to remove dust, dirt, and allergens.

---

### ✅ What I have to-do

---

- [ ]  Pick up items from floor
- [ ]  Vacuum entire room
- [ ]  Get under bed if accessible
- [ ]  Use edge tool for baseboards

### ❌ What I need to avoid

---

- Missing under furniture
- Using full vacuum bag
- Skipping corners

---