# Deep clean all shelves

Type: Chores
Status: Not started
Room: 🥫 Pantry (https://www.notion.so/Pantry-2ef97e9c2a3181979138c282576cd910?pvs=21)
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Deep clean all pantry shelves monthly, removing spills and reorganizing items.

---

### ✅ What I have to-do

---

- [ ]  Remove all items from shelves
- [ ]  Wipe shelves thoroughly
- [ ]  Check for expired items
- [ ]  Reorganize by category

### ❌ What I need to avoid

---

- Returning items to dirty shelves
- Keeping expired food
- Poor organization

---