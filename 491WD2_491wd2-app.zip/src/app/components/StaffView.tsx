import React from 'react';
import { Plus, Star } from 'lucide-react';

export function StaffView() {
  const mockStaff = [
    {
      id: 1,
      name: 'Jenny Kim',
      role: 'Senior Stylist',
      specialties: ['Cuts', 'Color', 'Styling'],
      rating: 4.9,
      appointmentsToday: 6,
      status: 'active',
    },
    {
      id: 2,
      name: 'Min Park',
      role: 'Color Specialist',
      specialties: ['Color', 'Highlights', 'Balayage'],
      rating: 4.8,
      appointmentsToday: 5,
      status: 'active',
    },
    {
      id: 3,
      name: 'Soo Lee',
      role: 'Stylist',
      specialties: ['Cuts', 'Perms', 'Treatment'],
      rating: 4.7,
      appointmentsToday: 4,
      status: 'break',
    },
    {
      id: 4,
      name: 'Grace Choi',
      role: 'Junior Stylist',
      specialties: ['Cuts', 'Styling'],
      rating: 4.6,
      appointmentsToday: 3,
      status: 'active',
    },
  ];

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-3xl text-gray-900 mb-2">Staff</h2>
          <p className="text-gray-400">{mockStaff.length} team members</p>
        </div>
        <button className="flex items-center gap-2 px-6 py-3 bg-[#8B5A7C] text-white rounded-2xl hover:bg-[#7A4F6C] transition-colors">
          <Plus className="w-5 h-5" />
          <span>Add Staff</span>
        </button>
      </div>

      <div className="grid grid-cols-2 gap-6">
        {mockStaff.map((staff) => (
          <div
            key={staff.id}
            className="bg-white rounded-3xl p-6 hover:shadow-sm transition-shadow border border-gray-100"
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#E8D5E8] to-[#D4C5E8] flex items-center justify-center">
                  <span className="text-lg text-[#8B5A7C]">
                    {staff.name
                      .split(' ')
                      .map((n) => n[0])
                      .join('')}
                  </span>
                </div>
                <div>
                  <h3 className="text-lg text-gray-900 mb-1">{staff.name}</h3>
                  <p className="text-sm text-gray-500">{staff.role}</p>
                </div>
              </div>
              <span
                className={`px-3 py-1 rounded-full text-xs ${
                  staff.status === 'active'
                    ? 'bg-[#F0F4E8] text-[#6B8B5A]'
                    : 'bg-[#FFF4E8] text-[#8B7A5A]'
                }`}
              >
                {staff.status === 'active' ? 'Active' : 'On Break'}
              </span>
            </div>

            <div className="space-y-4">
              <div>
                <p className="text-sm text-gray-500 mb-2">Specialties</p>
                <div className="flex flex-wrap gap-2">
                  {staff.specialties.map((specialty, index) => (
                    <span
                      key={index}
                      className="px-3 py-1 bg-[#F5E6F1] text-[#8B5A7C] rounded-full text-xs"
                    >
                      {specialty}
                    </span>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                <div className="flex items-center gap-2">
                  <Star className="w-4 h-4 text-[#FFB800] fill-[#FFB800]" />
                  <span className="text-sm text-gray-900">{staff.rating}</span>
                </div>
                <div className="text-right">
                  <p className="text-sm text-gray-500">Today</p>
                  <p className="text-lg text-gray-900">
                    {staff.appointmentsToday} appointments
                  </p>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
