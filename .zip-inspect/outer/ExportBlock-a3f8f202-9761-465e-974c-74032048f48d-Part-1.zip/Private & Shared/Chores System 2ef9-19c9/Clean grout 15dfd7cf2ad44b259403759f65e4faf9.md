# Clean grout

Type: Chores
Status: Not started
Room: 🚽 Half Bath (https://www.notion.so/Half-Bath-2ef97e9c2a3181d881c4f8476b0304b8?pvs=21)
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Clean bathroom tile grout monthly to remove mold, mildew, and discoloration.

---

### ✅ What I have to-do

---

- [ ]  Apply grout cleaner
- [ ]  Let sit for recommended time
- [ ]  Scrub with grout brush
- [ ]  Rinse thoroughly

### ❌ What I need to avoid

---

- Using metal brushes
- Mixing cleaning chemicals
- Skipping ventilation

---