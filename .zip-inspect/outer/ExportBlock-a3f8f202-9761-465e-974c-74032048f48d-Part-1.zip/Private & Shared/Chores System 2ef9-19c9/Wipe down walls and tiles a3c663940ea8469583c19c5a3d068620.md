# Wipe down walls and tiles

Type: Chores
Status: Not started
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Wipe down bathroom walls and tiles monthly to remove soap scum and moisture buildup.

---

### ✅ What I have to-do

---

- [ ]  Start from ceiling down
- [ ]  Clean all tile surfaces
- [ ]  Wipe painted walls
- [ ]  Dry thoroughly

### ❌ What I need to avoid

---

- Leaving moisture
- Using harsh tile cleaners on paint
- Missing grout lines

---