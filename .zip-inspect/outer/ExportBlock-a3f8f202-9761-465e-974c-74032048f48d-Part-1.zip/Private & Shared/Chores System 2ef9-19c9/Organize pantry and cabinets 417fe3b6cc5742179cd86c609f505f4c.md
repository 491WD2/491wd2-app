# Organize pantry and cabinets

Type: Chores
Status: Not started
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Organize kitchen pantry and cabinets monthly for efficient storage and easy access.

---

### ✅ What I have to-do

---

- [ ]  Remove all items
- [ ]  Wipe shelves clean
- [ ]  Check expiration dates
- [ ]  Group by category and return

### ❌ What I need to avoid

---

- Keeping expired food
- Random placement
- Blocking frequently used items

---