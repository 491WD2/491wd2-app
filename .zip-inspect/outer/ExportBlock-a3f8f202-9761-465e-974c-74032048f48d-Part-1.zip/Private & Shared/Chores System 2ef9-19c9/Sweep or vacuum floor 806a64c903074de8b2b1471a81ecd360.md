# Sweep or vacuum floor

Type: Chores
Status: Not started
Room: 🚪 Entry (https://www.notion.so/Entry-2ef97e9c2a3181f78171fb35aa12d167?pvs=21)
Completion %: 0%
Frequency: Daily

### ✏️ Cleaning Description

---

Sweep or vacuum the entryway floor to remove dirt, leaves, and debris tracked in from outside.

---

### ✅ What I have to-do

---

- [ ]  Remove large debris by hand
- [ ]  Sweep or vacuum thoroughly
- [ ]  Get corners and edges
- [ ]  Clean entryway mat

### ❌ What I need to avoid

---

- Pushing dirt outside without cleaning
- Missing under furniture or mats
- Letting dirt spread to other rooms

---