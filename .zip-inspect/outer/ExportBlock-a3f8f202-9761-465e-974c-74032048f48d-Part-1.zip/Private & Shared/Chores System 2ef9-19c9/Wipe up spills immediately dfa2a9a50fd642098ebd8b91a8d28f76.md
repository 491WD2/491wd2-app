# Wipe up spills immediately

Type: Chores
Status: Not started
Room: 🥫 Pantry (https://www.notion.so/Pantry-2ef97e9c2a3181979138c282576cd910?pvs=21)
Completion %: 0%
Frequency: Daily

### ✏️ Cleaning Description

---

Clean up spills immediately to prevent stains and sticky residue in the pantry.

---

### ✅ What I have to-do

---

- [ ]  Blot spill immediately
- [ ]  Use appropriate cleaner
- [ ]  Wipe surrounding area
- [ ]  Dry completely

### ❌ What I need to avoid

---

- Letting spills set
- Spreading spill while cleaning
- Leaving damp spots

---