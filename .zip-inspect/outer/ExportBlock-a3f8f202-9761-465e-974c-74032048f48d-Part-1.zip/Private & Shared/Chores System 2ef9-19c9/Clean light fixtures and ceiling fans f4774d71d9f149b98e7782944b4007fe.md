# Clean light fixtures and ceiling fans

Type: Chores
Status: Not started
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Clean all light fixtures and ceiling fans monthly throughout the room.

---

### ✅ What I have to-do

---

- [ ]  Turn off power completely
- [ ]  Dust fan blades both sides
- [ ]  Clean fixture covers
- [ ]  Wipe motor housing

### ❌ What I need to avoid

---

- Working with power on
- Using excess moisture
- Forcing stuck components

---