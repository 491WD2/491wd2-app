# Bedroom (Make bed, put away clothes, clear nightstands)

Date: February 3, 2026
Type: Chores
Status: Not started
Assigned To: Nox
Completion %: 0%

### ✏️ Cleaning Description

---

<aside>
▪️

</aside>

---

### ✅ What I have to-do

---

- [ ]  Sub-task to-do…
- [ ]  Sub-task to-do…
- [ ]  Sub-task to-do…

### ❌ What I need to avoid

---

- Thing to avoid
- Thing to avoid
- Thing to avoid

---