# Vacuum under bed

Type: Chores
Status: Not started
Room: 🛏️ Bedroom (https://www.notion.so/Bedroom-2ef97e9c2a318104bfe5c06efed42020?pvs=21)
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Vacuum under the bed monthly to remove dust, dirt, and allergens.

---

### ✅ What I have to-do

---

- [ ]  Move bed away from wall if needed
- [ ]  Vacuum entire area underneath
- [ ]  Get corners and edges
- [ ]  Return bed to position

### ❌ What I need to avoid

---

- Leaving dust bunnies
- Missing far corners
- Scratching floors when moving bed

---