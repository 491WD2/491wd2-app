# Scrub toilet thoroughly

Type: Chores
Status: Not started
Completion %: 0%
Frequency: Weekly

### ✏️ Cleaning Description

---

Wipe down bathroom vanity weekly to remove product residue and maintain cleanliness.

---

### ✅ What I have to-do

---

- [ ]  Clear vanity surface
- [ ]  Wipe entire counter
- [ ]  Clean around faucet
- [ ]  Organize items back neatly

### ❌ What I need to avoid

---

- Leaving product residue
- Missing behind items
- Using harsh cleaners

---