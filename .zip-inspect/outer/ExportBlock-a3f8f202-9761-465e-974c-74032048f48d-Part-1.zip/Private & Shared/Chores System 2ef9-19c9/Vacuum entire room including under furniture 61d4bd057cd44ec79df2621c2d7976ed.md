# Vacuum entire room including under furniture

Type: Chores
Status: Not started
Completion %: 0%
Frequency: Weekly

### ✏️ Cleaning Description

---

Wipe refrigerator shelves and drawers weekly to remove spills and maintain freshness.

---

### ✅ What I have to-do

---

- [ ]  Remove items from one shelf
- [ ]  Wipe shelf thoroughly
- [ ]  Clean drawer fronts
- [ ]  Check for expired items

### ❌ What I need to avoid

---

- Leaving spills
- Missing drawer tracks
- Keeping expired food

---