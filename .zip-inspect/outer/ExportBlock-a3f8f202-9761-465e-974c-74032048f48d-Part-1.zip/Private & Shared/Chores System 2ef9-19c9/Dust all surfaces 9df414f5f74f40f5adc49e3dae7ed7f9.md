# Dust all surfaces

Type: Chores
Status: Not started
Room: 👨‍👩‍👧‍👦 Family Room (https://www.notion.so/Family-Room-2ef97e9c2a3181c7b087f2438a1f9bf9?pvs=21)
Completion %: 0%
Frequency: Weekly

### ✏️ Cleaning Description

---

Dust all surfaces weekly in the family room including shelves, tables, and decor.

---

### ✅ What I have to-do

---

- [ ]  Use microfiber cloth or duster
- [ ]  Dust from top to bottom
- [ ]  Get all horizontal surfaces
- [ ]  Don't forget picture frames

### ❌ What I need to avoid

---

- Spreading dust around
- Missing high surfaces
- Using dirty dusting tools

---