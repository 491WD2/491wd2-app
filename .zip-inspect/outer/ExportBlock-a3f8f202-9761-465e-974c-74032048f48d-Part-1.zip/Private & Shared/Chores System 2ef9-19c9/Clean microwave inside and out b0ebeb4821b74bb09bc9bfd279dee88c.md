# Clean microwave inside and out

Type: Chores
Status: Not started
Completion %: 0%
Frequency: Weekly

### ✏️ Cleaning Description

---

Clean microwave inside and out weekly to remove food splatters and odors.

---

### ✅ What I have to-do

---

- [ ]  Heat bowl of water with lemon
- [ ]  Wipe interior with damp cloth
- [ ]  Clean door and exterior
- [ ]  Remove and wash turntable

### ❌ What I need to avoid

---

- Using abrasive cleaners
- Leaving food residue
- Forgetting door seals

---