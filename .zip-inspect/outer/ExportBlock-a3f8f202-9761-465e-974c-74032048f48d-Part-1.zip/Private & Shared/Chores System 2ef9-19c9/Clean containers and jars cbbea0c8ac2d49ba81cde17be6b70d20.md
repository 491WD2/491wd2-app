# Clean containers and jars

Type: Chores
Status: Not started
Room: 🥫 Pantry (https://www.notion.so/Pantry-2ef97e9c2a3181979138c282576cd910?pvs=21)
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Clean and organize pantry containers and jars, removing spills and expired items.

---

### ✅ What I have to-do

---

- [ ]  Remove all containers
- [ ]  Wipe down each one
- [ ]  Check for expired contents
- [ ]  Return organized by category

### ❌ What I need to avoid

---

- Returning sticky containers
- Keeping expired items
- Poor labeling

---