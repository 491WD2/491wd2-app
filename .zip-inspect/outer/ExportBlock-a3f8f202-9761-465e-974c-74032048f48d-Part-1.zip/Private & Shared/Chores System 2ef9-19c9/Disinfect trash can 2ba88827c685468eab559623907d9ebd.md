# Disinfect trash can

Type: Chores
Status: Not started
Completion %: 0%
Frequency: Weekly

### ✏️ Cleaning Description

---

Clean and disinfect kitchen trash can weekly to prevent odors and bacteria.

---

### ✅ What I have to-do

---

- [ ]  Remove liner and empty
- [ ]  Spray with disinfectant
- [ ]  Scrub inside and out
- [ ]  Rinse and dry completely

### ❌ What I need to avoid

---

- Replacing liner in wet can
- Missing the lid
- Skipping the exterior

---