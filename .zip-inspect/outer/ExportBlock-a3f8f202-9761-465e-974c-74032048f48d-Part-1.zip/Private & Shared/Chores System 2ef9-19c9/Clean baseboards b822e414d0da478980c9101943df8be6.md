# Clean baseboards

Type: Chores
Status: Not started
Room: 🚽 Half Bath (https://www.notion.so/Half-Bath-2ef97e9c2a3181d881c4f8476b0304b8?pvs=21)
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Clean bathroom baseboards monthly to remove dust, hair, and moisture buildup.

---

### ✅ What I have to-do

---

- [ ]  Remove dust and hair
- [ ]  Wipe with disinfecting cleaner
- [ ]  Clean behind toilet area
- [ ]  Dry thoroughly

### ❌ What I need to avoid

---

- Leaving hair and dust
- Missing behind toilet
- Using too much water

---