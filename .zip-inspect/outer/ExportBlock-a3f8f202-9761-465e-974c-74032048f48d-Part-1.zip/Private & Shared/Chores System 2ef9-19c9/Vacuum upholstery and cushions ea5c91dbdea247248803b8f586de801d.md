# Vacuum upholstery and cushions

Type: Chores
Status: Not started
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Vacuum upholstery and cushions monthly to remove dust and maintain freshness.

---

### ✅ What I have to-do

---

- [ ]  Remove all cushions
- [ ]  Vacuum cushion surfaces
- [ ]  Vacuum under cushions
- [ ]  Use upholstery attachment

### ❌ What I need to avoid

---

- Rough scrubbing that damages
- Missing between crevices
- Using wrong vacuum setting

---