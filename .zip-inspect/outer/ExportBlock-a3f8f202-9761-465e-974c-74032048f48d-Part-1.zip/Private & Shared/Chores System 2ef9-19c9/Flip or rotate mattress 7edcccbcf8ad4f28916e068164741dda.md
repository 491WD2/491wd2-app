# Flip or rotate mattress

Type: Chores
Status: Not started
Room: 🛏️ Bedroom (https://www.notion.so/Bedroom-2ef97e9c2a318104bfe5c06efed42020?pvs=21)
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Flip or rotate the mattress monthly to ensure even wear and extend its lifespan.

---

### ✅ What I have to-do

---

- [ ]  Strip all bedding
- [ ]  Flip or rotate mattress
- [ ]  Vacuum mattress surface
- [ ]  Replace fresh bedding

### ❌ What I need to avoid

---

- Flipping one-sided mattresses
- Trying to lift alone if heavy
- Skipping mattress vacuuming

---