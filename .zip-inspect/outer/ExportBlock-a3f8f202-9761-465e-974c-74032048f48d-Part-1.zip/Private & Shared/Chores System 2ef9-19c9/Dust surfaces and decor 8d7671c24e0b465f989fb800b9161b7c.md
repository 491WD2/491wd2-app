# Dust surfaces and decor

Type: Chores
Status: Not started
Room: 🚪 Entry (https://www.notion.so/Entry-2ef97e9c2a3181f78171fb35aa12d167?pvs=21)
Completion %: 0%
Frequency: Weekly

### ✏️ Cleaning Description

---

Dust bedroom furniture weekly including dresser, nightstands, and shelves.

---

### ✅ What I have to-do

---

- [ ]  Start from top surfaces
- [ ]  Use microfiber cloth
- [ ]  Dust all furniture pieces
- [ ]  Don't forget drawer fronts

### ❌ What I need to avoid

---

- Missing furniture tops
- Spreading dust around
- Using dirty cloths

---