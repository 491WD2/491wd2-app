# Fluff cushions

Type: Chores
Status: Not started
Room: 👨‍👩‍👧‍👦 Family Room (https://www.notion.so/Family-Room-2ef97e9c2a3181c7b087f2438a1f9bf9?pvs=21)
Completion %: 0%
Frequency: Daily

### ✏️ Cleaning Description

Fluff and arrange couch cushions to maintain their shape, comfort, and create a tidy, welcoming family room appearance.

---

### 📋 Step-by-Step Instructions

- [ ]  Remove all cushions from couch or chairs
- [ ]  Check underneath for crumbs or lost items
- [ ]  Vacuum or brush off any debris from cushions
- [ ]  Fluff each cushion by hitting and kneading it
- [ ]  Rotate cushions for even wear distribution
- [ ]  Check cushion covers for stains or spills
- [ ]  Arrange cushions neatly back in place
- [ ]  Ensure cushions are evenly positioned

### ⚠️ Important Safety & Mistakes to Avoid

- Don't skip rotating cushions regularly
- Avoid ignoring debris or crumbs underneath
- Never place cushions unevenly or haphazardly
- Don't forget to fluff cushions that look flat
- Avoid leaving stains untreated on cushion covers

---