# Organize closet

Type: Chores
Status: Not started
Room: 🚪 Entry (https://www.notion.so/Entry-2ef97e9c2a3181f78171fb35aa12d167?pvs=21)
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Organize entryway closet monthly, removing items that don't belong and tidying storage.

---

### ✅ What I have to-do

---

- [ ]  Remove everything from closet
- [ ]  Vacuum and wipe shelves
- [ ]  Sort and donate unused items
- [ ]  Organize remaining items neatly

### ❌ What I need to avoid

---

- Keeping items you don't use
- Overstuffing the space
- Poor hanging and storage

---