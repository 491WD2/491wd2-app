# Wipe down surfaces

Type: Chores
Status: Not started
Room: 👨‍👩‍👧‍👦 Family Room (https://www.notion.so/Family-Room-2ef97e9c2a3181c7b087f2438a1f9bf9?pvs=21)
Completion %: 0%
Frequency: Daily

### ✏️ Cleaning Description

---

Wipe down all surfaces in the family room including tables, shelves, and entertainment center.

---

### ✅ What I have to-do

---

- [ ]  Remove items from surfaces
- [ ]  Dust all surfaces
- [ ]  Wipe with appropriate cleaner
- [ ]  Return items neatly

### ❌ What I need to avoid

---

- Using too much liquid on electronics
- Missing remote controls and devices
- Scratching screens

---