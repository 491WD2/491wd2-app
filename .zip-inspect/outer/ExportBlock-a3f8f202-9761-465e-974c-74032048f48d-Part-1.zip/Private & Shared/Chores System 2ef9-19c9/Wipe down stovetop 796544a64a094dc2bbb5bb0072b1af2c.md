# Wipe down stovetop

Type: Chores
Status: Not started
Completion %: 0%
Frequency: Daily

### ✏️ Cleaning Description

---

Wipe down the stovetop daily to remove grease, spills, and food debris.

---

### ✅ What I have to-do

---

- [ ]  Remove burner grates or coils
- [ ]  Spray stovetop with cleaner
- [ ]  Scrub stubborn spots
- [ ]  Wipe clean and replace grates

### ❌ What I need to avoid

---

- Cleaning while stovetop is hot
- Using abrasive scrubbers on glass tops
- Leaving grease buildup

---