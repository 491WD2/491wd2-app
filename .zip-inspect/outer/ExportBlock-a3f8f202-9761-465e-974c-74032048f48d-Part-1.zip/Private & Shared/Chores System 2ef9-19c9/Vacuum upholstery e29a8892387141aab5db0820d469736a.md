# Vacuum upholstery

Type: Chores
Status: Not started
Room: 👨‍👩‍👧‍👦 Family Room (https://www.notion.so/Family-Room-2ef97e9c2a3181c7b087f2438a1f9bf9?pvs=21)
Completion %: 0%
Frequency: Monthly

### ✏️ Cleaning Description

---

Vacuum family room upholstery monthly to remove dust, crumbs, and pet hair.

---

### ✅ What I have to-do

---

- [ ]  Remove cushions
- [ ]  Vacuum under cushions
- [ ]  Vacuum cushions and upholstery
- [ ]  Use brush attachment

### ❌ What I need to avoid

---

- Using wrong attachment
- Missing crevices
- Damaging delicate fabrics

---