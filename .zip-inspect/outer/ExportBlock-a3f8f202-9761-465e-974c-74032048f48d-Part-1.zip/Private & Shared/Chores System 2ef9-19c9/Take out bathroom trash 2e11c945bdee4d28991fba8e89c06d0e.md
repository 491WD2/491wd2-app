# Take out bathroom trash

Type: Chores
Status: Not started
Room: 🗑️ Trash & Recycling (https://www.notion.so/Trash-Recycling-2ef97e9c2a3181249089f3915f94b75c?pvs=21)
Completion %: 0%
Frequency: Daily

### ✏️ Cleaning Description

---

Empty bathroom trash daily to maintain cleanliness and prevent odors.

---

### ✅ What I have to-do

---

- [ ]  Remove trash bag from bin
- [ ]  Tie bag securely
- [ ]  Take to main trash collection
- [ ]  Replace with fresh liner

### ❌ What I need to avoid

---

- Overfilling the bin
- Leaving without a liner
- Ignoring spills in the bin

---