import React from 'react';
import { Calendar, Users, UserCircle, BarChart3, Package, Settings, History } from 'lucide-react';
import { ViewType } from '../App';

interface SidebarProps {
  currentView: ViewType;
  onViewChange: (view: ViewType) => void;
}

export function Sidebar({ currentView, onViewChange }: SidebarProps) {
  const navItems = [
    { id: 'calendar' as ViewType, label: 'Calendar', icon: Calendar },
    { id: 'clients' as ViewType, label: 'Clients', icon: Users },
    { id: 'staff' as ViewType, label: 'Staff', icon: UserCircle },
    { id: 'stock' as ViewType, label: 'Stock', icon: Package },
    { id: 'reports' as ViewType, label: 'Reports', icon: BarChart3 },
    { id: 'history' as ViewType, label: 'History', icon: History },
    { id: 'settings' as ViewType, label: 'Settings', icon: Settings },
  ];

  return (
    <aside className="w-64 bg-white border-r border-gray-100 flex flex-col">
      <div className="p-8">
        <h1 className="text-2xl tracking-tight text-gray-900">Salon</h1>
        <p className="text-sm text-gray-400 mt-1">Management</p>
      </div>

      <nav className="flex-1 px-4">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onViewChange(item.id)}
              className={`w-full flex items-center gap-3 px-5 py-4 rounded-2xl mb-2 transition-all ${
                isActive
                  ? 'bg-[#F5E6F1] text-[#8B5A7C]'
                  : 'text-gray-500 hover:bg-gray-50'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="font-medium">{item.label}</span>
            </button>
          );
        })}
      </nav>

      <div className="p-6 border-t border-gray-100">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#E8D5E8] to-[#D4C5E8] flex items-center justify-center">
            <span className="text-sm text-[#8B5A7C]">AS</span>
          </div>
          <div>
            <p className="text-sm text-gray-900">Admin</p>
            <p className="text-xs text-gray-400">Logged in</p>
          </div>
        </div>
      </div>
    </aside>
  );
}