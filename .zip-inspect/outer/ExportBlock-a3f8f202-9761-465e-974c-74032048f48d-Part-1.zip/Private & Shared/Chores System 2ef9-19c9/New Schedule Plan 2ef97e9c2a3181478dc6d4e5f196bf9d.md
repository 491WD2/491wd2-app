# New Schedule Plan

Date: December 22, 2023
Type: Cleaning Session
Status: Not started
Completion %: 0%

### 🗓️ What is planned?

---

<aside>
<img src="https://www.notion.so/icons/clipping_gray.svg" alt="https://www.notion.so/icons/clipping_gray.svg" width="40px" />

</aside>

---