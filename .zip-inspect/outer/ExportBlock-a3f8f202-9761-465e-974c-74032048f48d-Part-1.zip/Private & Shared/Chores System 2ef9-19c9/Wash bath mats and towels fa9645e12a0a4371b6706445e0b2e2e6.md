# Wash bath mats and towels

Type: Chores
Status: Not started
Completion %: 0%
Frequency: Weekly